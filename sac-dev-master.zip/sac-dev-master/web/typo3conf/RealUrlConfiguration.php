<?php

$defaultConf = [
    'init' => [
        'enableCHashCache' => 1,
        'appendMissingSlash' => 'ifNotFile,redirect[301]',
        'enableUrlDecodeCache' => 1,
        'enableUrlEncodeCache' => 1,
        'emptyUrlReturnValue' => '/',
        'disableErrorLog' => 1
    ],
    'preVars' => [
        0 => [
            'GETvar' => 'L',
            'valueMap' => [
                'de' => '0',
                'fr' => '1',
                'it' => '2',
                'en' => '3',
            ],
        ],
    ],
    'pagePath' => [
        'type' => 'user',
        'userFunc' => 'EXT:realurl/class.tx_realurl_advanced.php:&tx_realurl_advanced->main',
        'spaceCharacter' => '-',
        'languageGetVar' => 'L',
        'expireDays' => '7',
        'disablePathCache' => '0',
    ],
    'fixedPostVars' => [
        'newsDetailConfiguration' => [
            [
                'GETvar' => 'tx_news_pi1[action]',
                'valueMap' => [
                    'detail' => '',
                ],
                'noMatch' => 'bypass'
            ],
            [
                'GETvar' => 'tx_news_pi1[controller]',
                'valueMap' => [
                    'News' => '',
                ],
                'noMatch' => 'bypass'
            ],
            [
                'GETvar' => 'tx_news_pi1[news]',
                'lookUpTable' => [
                    'table' => 'tx_news_domain_model_news',
                    'id_field' => 'uid',
                    'alias_field' => 'CONCAT(IF(path_segment!=\'\',path_segment,title), \'-\', uid)',
                    'addWhereClause' => ' AND NOT deleted',
                    'useUniqueCache' => 1,
                    'useUniqueCache_conf' => [
                        'strtolower' => 1,
                        'spaceCharacter' => '-'
                    ],
                    'languageGetVar' => 'L',
                    'languageExceptionUids' => '',
                    'languageField' => 'sys_language_uid',
                    'transOrigPointerField' => 'l10n_parent',
                    'autoUpdate' => 1,
                    'expireDays' => 180,
                ],
            ],
        ],
        261 => 'newsDetailConfiguration',
        3 => 'newsDetailConfiguration',
        24 => 'newsDetailConfiguration',
        4 => 'newsDetailConfiguration',
        5 => 'newsDetailConfiguration',
        6 => 'newsDetailConfiguration',
        7 => 'newsDetailConfiguration',
        8 => 'newsDetailConfiguration', // Der SAC
        42 => 'newsDetailConfiguration', // Sportklettern
        43 => 'newsDetailConfiguration', // Skitourenrennen
        44 => 'newsDetailConfiguration', // Eisklettern
        45 => 'newsDetailConfiguration', // Bergsteigen

        'sac2020DetailConfiguration' => [
            [
                'GETvar' => 'tx_usersaccas2020_sac2020[poiId]',
            ],
            [
                'GETvar' => 'tx_usersaccas2020_sac2020[discipline]',
            ],
            [
                'GETvar' => 'tx_usersaccas2020_sac2020[routeId]',
            ],
        ],
        308 => 'sac2020DetailConfiguration',

        'coursesDetailConfiguration' => [
            [
                'GETvar' => 'tx_usersaccascourseshop_course[action]',
                'valueMap' => [
                    'show' => '',
                ],
                'noMatch' => 'bypass'
            ],
            [
                'GETvar' => 'tx_usersaccascourseshop_course[controller]',
                'valueMap' => [
                    'Course' => '',
                ],
                'noMatch' => 'bypass'
            ],
            [
                'GETvar' => 'tx_usersaccascourseshop_course[selectedcourse]',
                'lookUpTable' => [
                    'table' => 'tx_usersaccascourseshop_domain_model_course',
                    'id_field' => 'uid',
                    'alias_field' => 'CONCAT(articlenumber, \' \', location)',
                    'addWhereClause' => ' AND NOT deleted',
                    'useUniqueCache' => 1,
                    'useUniqueCache_conf' => [
                        'strtolower' => 1,
                        'spaceCharacter' => '-'
                    ],
                    'languageGetVar' => 'L',
                    'languageExceptionUids' => '',
                    'languageField' => 'sys_language_uid',
                    'transOrigPointerField' => 'l10n_parent',
                    'autoUpdate' => 1,
                    'expireDays' => 180,
                ],
            ],
        ],
        389 => 'coursesDetailConfiguration',
    ],
    'postVarSets' => [
        '_DEFAULT' => [
            'page' => [
                [
                    'GETvar' => 'tx_news_pi1[@widget_0][currentPage]',
                ],
            ],
        ]
    ],
    'fileName' =>  [
        'defaultToHTMLsuffixOnPrev' => 0,
        'acceptHTMLsuffix' => 0,
        'index' =>  [
            'ajaxNews.feed' => [
                'keyValues' => [
                    'type' => '1485857210',
                ],
            ],
            'ajaxEvents.feed' => [
                'keyValues' => [
                    'type' => '1485857211',
                ],
            ],
            'calentry.ics' => [
                'keyValues' => [
                    'type' => '1485857212',
                ],
            ],
            'sitemap.xml' =>  [
                'keyValues' =>  [
                    'type' => '655',
                ],
            ],
            'robots.txt' =>  [
                'keyValues' =>  [
                    'type' => '656',
                ],
            ],
        ],
    ],
];

$TYPO3_CONF_VARS['EXTCONF']['realurl'] = [
    '_DEFAULT' => $defaultConf,
    'sac-cas.ch' => $defaultConf,
];

unset($defaultConf);

$TYPO3_CONF_VARS['EXTCONF']['realurl']['sac-cas.ch']['pagePath']['rootpage_id'] = 1;
//$TYPO3_CONF_VARS['EXTCONF']['realurl']['sac-cas.ch']['pagePath']['pageNotFound_handling_redirectPageID'] = 55;

require_once(dirname(__FILE__) . '/../../Configuration/current/RealUrlConfiguration.php');
