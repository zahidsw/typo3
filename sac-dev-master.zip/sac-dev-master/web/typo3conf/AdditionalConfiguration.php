<?php
require_once(dirname(__FILE__) . '/../../Configuration/current/conf.php');
