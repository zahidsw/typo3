<?php
// PackageStates.php

// This file is maintained by TYPO3's package management. Although you can edit it
// manually, you should rather use the extension manager for maintaining packages.
// This file will be regenerated automatically if it doesn't exist. Deleting this file
// should, however, never become necessary if you use the package commands.

return [
    'packages' => [
        'core' => [
            'packagePath' => 'typo3/sysext/core/',
        ],
        'extbase' => [
            'packagePath' => 'typo3/sysext/extbase/',
        ],
        'fluid' => [
            'packagePath' => 'typo3/sysext/fluid/',
        ],
        'install' => [
            'packagePath' => 'typo3/sysext/install/',
        ],
        'frontend' => [
            'packagePath' => 'typo3/sysext/frontend/',
        ],
        'fluid_styled_content' => [
            'packagePath' => 'typo3/sysext/fluid_styled_content/',
        ],
        'info' => [
            'packagePath' => 'typo3/sysext/info/',
        ],
        'info_pagetsconfig' => [
            'packagePath' => 'typo3/sysext/info_pagetsconfig/',
        ],
        'extensionmanager' => [
            'packagePath' => 'typo3/sysext/extensionmanager/',
        ],
        'lang' => [
            'packagePath' => 'typo3/sysext/lang/',
        ],
        'setup' => [
            'packagePath' => 'typo3/sysext/setup/',
        ],
        'rte_ckeditor' => [
            'packagePath' => 'typo3/sysext/rte_ckeditor/',
        ],
        'rsaauth' => [
            'packagePath' => 'typo3/sysext/rsaauth/',
        ],
        'saltedpasswords' => [
            'packagePath' => 'typo3/sysext/saltedpasswords/',
        ],
        'func' => [
            'packagePath' => 'typo3/sysext/func/',
        ],
        'wizard_crpages' => [
            'packagePath' => 'typo3/sysext/wizard_crpages/',
        ],
        'wizard_sortpages' => [
            'packagePath' => 'typo3/sysext/wizard_sortpages/',
        ],
        'about' => [
            'packagePath' => 'typo3/sysext/about/',
        ],
        'backend' => [
            'packagePath' => 'typo3/sysext/backend/',
        ],
        'belog' => [
            'packagePath' => 'typo3/sysext/belog/',
        ],
        'beuser' => [
            'packagePath' => 'typo3/sysext/beuser/',
        ],
        'context_help' => [
            'packagePath' => 'typo3/sysext/context_help/',
        ],
        'cshmanual' => [
            'packagePath' => 'typo3/sysext/cshmanual/',
        ],
        'documentation' => [
            'packagePath' => 'typo3/sysext/documentation/',
        ],
        'felogin' => [
            'packagePath' => 'typo3/sysext/felogin/',
        ],
        'filelist' => [
            'packagePath' => 'typo3/sysext/filelist/',
        ],
        'filemetadata' => [
            'packagePath' => 'typo3/sysext/filemetadata/',
        ],
        'form' => [
            'packagePath' => 'typo3/sysext/form/',
        ],
        'impexp' => [
            'packagePath' => 'typo3/sysext/impexp/',
        ],
        'lowlevel' => [
            'packagePath' => 'typo3/sysext/lowlevel/',
        ],
        'recordlist' => [
            'packagePath' => 'typo3/sysext/recordlist/',
        ],
        'recycler' => [
            'packagePath' => 'typo3/sysext/recycler/',
        ],
        'reports' => [
            'packagePath' => 'typo3/sysext/reports/',
        ],
        'scheduler' => [
            'packagePath' => 'typo3/sysext/scheduler/',
        ],
        'sv' => [
            'packagePath' => 'typo3/sysext/sv/',
        ],
        'sys_note' => [
            'packagePath' => 'typo3/sysext/sys_note/',
        ],
        'tstemplate' => [
            'packagePath' => 'typo3/sysext/tstemplate/',
        ],
        'version' => [
            'packagePath' => 'typo3/sysext/version/',
        ],
        'viewpage' => [
            'packagePath' => 'typo3/sysext/viewpage/',
        ],
        'handlebars' => [
            'packagePath' => 'typo3conf/ext/handlebars/',
        ],
        'usersaccassite' => [
            'packagePath' => 'typo3conf/ext/usersaccassite/',
        ],
        'locales' => [
            'packagePath' => 'typo3conf/ext/locales/',
        ],
        'usersaccas2020' => [
            'packagePath' => 'typo3conf/ext/usersaccas2020/',
        ],
        'tt_address' => [
            'packagePath' => 'typo3conf/ext/tt_address/',
        ],
        'cdsrc_ttaddress_l18n' => [
            'packagePath' => 'typo3conf/ext/cdsrc_ttaddress_l18n/',
        ],
        'static_info_tables' => [
            'packagePath' => 'typo3conf/ext/static_info_tables/',
        ],
        'realurl' => [
            'packagePath' => 'typo3conf/ext/realurl/',
        ],
        'cs_seo' => [
            'packagePath' => 'typo3conf/ext/cs_seo/',
        ],
        'news' => [
            'packagePath' => 'typo3conf/ext/news/',
        ],
        'eventnews' => [
            'packagePath' => 'typo3conf/ext/eventnews/',
        ],
        'news_importicsxml' => [
            'packagePath' => 'typo3conf/ext/news_importicsxml/',
        ],
        'powermail' => [
            'packagePath' => 'typo3conf/ext/powermail/',
        ],
        'powermail_cond' => [
            'packagePath' => 'typo3conf/ext/powermail_cond/',
        ],
        'rh_recaptcha' => [
            'packagePath' => 'typo3conf/ext/rh_recaptcha/',
        ],
        'static_info_tables_de' => [
            'packagePath' => 'typo3conf/ext/static_info_tables_de/',
        ],
        'static_info_tables_fr' => [
            'packagePath' => 'typo3conf/ext/static_info_tables_fr/',
        ],
        'static_info_tables_it' => [
            'packagePath' => 'typo3conf/ext/static_info_tables_it/',
        ],
        'additional_reports' => [
            'packagePath' => 'typo3conf/ext/additional_reports/',
        ],
        'aus_driver_amazon_s3' => [
            'packagePath' => 'typo3conf/ext/aus_driver_amazon_s3/',
        ],
        'autoswitchtolistview' => [
            'packagePath' => 'typo3conf/ext/autoswitchtolistview/',
        ],
        'be_secure_pw' => [
            'packagePath' => 'typo3conf/ext/be_secure_pw/',
        ],
        'cms_fluid_precompiler_module' => [
            'packagePath' => 'typo3conf/ext/cms_fluid_precompiler_module/',
        ],
        'commercetools' => [
            'packagePath' => 'typo3conf/ext/commercetools/',
        ],
        'error404page' => [
            'packagePath' => 'typo3conf/ext/error404page/',
        ],
        'extractor' => [
            'packagePath' => 'typo3conf/ext/extractor/',
        ],
        'fal_securedownload' => [
            'packagePath' => 'typo3conf/ext/fal_securedownload/',
        ],
        'gridelements' => [
            'packagePath' => 'typo3conf/ext/gridelements/',
        ],
        'imageoptimizer' => [
            'packagePath' => 'typo3conf/ext/imageoptimizer/',
        ],
        'min' => [
            'packagePath' => 'typo3conf/ext/min/',
        ],
        'my_redirects' => [
            'packagePath' => 'typo3conf/ext/my_redirects/',
        ],
        'oidc' => [
            'packagePath' => 'typo3conf/ext/oidc/',
        ],
        'routing' => [
            'packagePath' => 'typo3conf/ext/routing/',
        ],
        'solr' => [
            'packagePath' => 'typo3conf/ext/solr/',
        ],
        'sr_freecap' => [
            'packagePath' => 'typo3conf/ext/sr_freecap/',
        ],
        'typo3_console' => [
            'packagePath' => 'typo3conf/ext/typo3_console/',
        ],
        'usersaccascourseshop' => [
            'packagePath' => 'typo3conf/ext/usersaccascourseshop/',
        ],
        'usersaccasemail' => [
            'packagePath' => 'typo3conf/ext/usersaccasemail/',
        ],
        'usersaccaserrors' => [
            'packagePath' => 'typo3conf/ext/usersaccaserrors/',
        ],
        'usersaccastranslations' => [
            'packagePath' => 'typo3conf/ext/usersaccastranslations/',
        ],
        'variables' => [
            'packagePath' => 'typo3conf/ext/variables/',
        ],
        'vhs' => [
            'packagePath' => 'typo3conf/ext/vhs/',
        ],
        'wh_save_buttons' => [
            'packagePath' => 'typo3conf/ext/wh_save_buttons/',
        ],
    ],
    'version' => 5,
];
