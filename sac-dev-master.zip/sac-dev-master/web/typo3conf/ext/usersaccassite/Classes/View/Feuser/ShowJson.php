<?php
namespace Saccas\Usersaccassite\View\Feuser;

class ShowJson extends \TYPO3\CMS\Extbase\Mvc\View\JsonView
{
    /**
     * @var array
     */
    protected $configuration = [
        'feuser' => [
            '_only' => [
                'gender',
                'first_name',
                'last_name',
                'profil_image_url',
                ''
            ],
        ],
    ];
}
