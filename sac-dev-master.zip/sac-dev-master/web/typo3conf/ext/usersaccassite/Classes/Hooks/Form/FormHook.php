<?php
namespace Saccas\Usersaccassite\Hooks\Form;

class FormHook
{
    /**
     * @param \TYPO3\CMS\Form\Domain\Model\Renderable\RenderableInterface $renderable
     */
    public function initializeFormElement(\TYPO3\CMS\Form\Domain\Model\Renderable\RenderableInterface $renderable)
    {
        if ($renderable->getUniqueIdentifier() === 'feuserupdate-lastname') {
            $renderable->setDefaultValue('foo');
        }
    }

    /**
     * @param \TYPO3\CMS\Form\Domain\Runtime\FormRuntime $formRuntime
     * @param \TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface $currentPage
     * @param null|\TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface $lastPage
     * @param mixed $elementValue submitted value of the element *before post processing*
     * @return \TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface
     */
    public function afterInitializeCurrentPage(\TYPO3\CMS\Form\Domain\Runtime\FormRuntime $formRuntime, \TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface $currentPage, \TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface $lastPage = null, array $requestArguments = []): \TYPO3\CMS\Form\Domain\Model\Renderable\CompositeRenderableInterface
    {
        if ($formRuntime->getIdentifier() === 'feuserupdate') {
            $renderables = $currentPage->getRenderablesRecursively();
            foreach ($renderables as $renderable) {
                if ($renderable->getIdentifier() === 'firstname') {
                    var_dump($renderable->getProperties());
                    $renderable->setDefaultValue('test');
                }
            }
        }
        return $currentPage;
    }
}
