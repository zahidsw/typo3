<?php

namespace Saccas\Usersaccassite\Hooks;

use TYPO3\CMS\Core\Utility\GeneralUtility;

class FlexFormHook
{
    /**
     * Hook for 7x
     *
     * @param array $dataStructure
     * @param array $conf
     * @param array $row
     * @param string $table
     */
    public function getFlexFormDS_postProcessDS(&$dataStructure, $conf, $row, $table)
    {
        if ($table === 'tt_content' && $row['CType'] === 'list' && $row['list_type'] === 'news_pi1') {
            $file = PATH_site . 'typo3conf/ext/usersaccassite/Configuration/FlexForm/Ext/News/NewFields.xml';
            $content = file_get_contents($file);
            if ($content) {
                $newField = GeneralUtility::xml2array($content);
                $dataStructure['sheets']['extraEntry'] = $newField;
            }
        }
    }

    /**
     * Hook for 8x
     *
     * @param array $dataStructure
     * @param array $identifier
     * @return array
     */
    public function parseDataStructureByIdentifierPostProcess(array $dataStructure, array $identifier): array
    {
        if ($identifier['type'] === 'tca' && $identifier['tableName'] === 'tt_content' && $identifier['dataStructureKey'] === 'news_pi1,list') {
            $file = PATH_site . 'typo3conf/ext/usersaccassite/Configuration/FlexForm/Ext/News/NewFields.xml';
            $content = file_get_contents($file);
            if ($content) {
                $newField = GeneralUtility::xml2array($content);
                $dataStructure['sheets']['extraEntry'] = $newField;
            }
        }
        return $dataStructure;
    }
}
