<?php

namespace Saccas\Usersaccassite\Hooks\PageLayoutView;

use TYPO3\CMS\Backend\Utility\BackendUtility;
use TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;

class CustomCTypePreviewRenderer implements PageLayoutViewDrawItemHookInterface
{

    /**
     * @var \TYPO3\CMS\Core\Resource\FileRepository
     * @inject
     */
    protected $fileRepository;

    /**
     * @var \Saccas\Usersaccassite\Domain\Repository\SponsorRepository
     * @inject
     */
    protected $sponsorRepository;

    /**
     * @param \TYPO3\CMS\Backend\View\PageLayoutView $parentObject
     * @param bool $drawItem
     * @param string $headerContent
     * @param string $itemContent
     * @param array $row
     */
    public function preProcess(\TYPO3\CMS\Backend\View\PageLayoutView &$parentObject, &$drawItem, &$headerContent, &$itemContent, array &$row)
    {
        $extCType = str_replace('usersaccassite_', '', $row['CType']);

        switch ($extCType) {
            case 'infobox':
            case 'media':
            case 'menu_pills_pages':
            case 'menu_tabs_pages':
            case 'menu_teaser_content_records':
            case 'menu_teaser_related_records':
            case 'messagebox':
            case 'sidebar_text_box':
            case 'vcard':
                $getPagesFromId = 'uid';
                $headerContent = '';
                $view = $this->initView($extCType);
                break;
            case 'menu_pills':
            case 'menu_tabs':
                $getPagesFromId = 'pid';
                $headerContent = '';
                $view = $this->initView($extCType);
                break;
            case 'sponsor':
                $view = $this->initView($extCType);

                if ($row['tx_usersaccassite_sponsor'] > 0) {
                    if (is_null($this->sponsorRepository)) {
                        $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
                        $this->sponsorRepository = $objectManager->get('Saccas\\Usersaccassite\\Domain\\Repository\\SponsorRepository');
                    }
                    $sponsorUids = GeneralUtility::intExplode(',', $row['tx_usersaccassite_sponsor']);
                    $sponsorElements = $this->sponsorRepository->findByUids($sponsorUids);
                    $row['sponsorElements'] = $sponsorElements;
                }
                break;
        }

        if (!is_object($view)) {
            return;
        }

        $row['backendEditUrl'] = $this->getBackendEditUrl($row['uid']);
        $row['sacCType'] = $extCType;
        $row['ttContentUid'] = $row['uid'];

        if ($row['pages'] > 0) {
            $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('pages');
            $pageElements = $queryBuilder
                            ->select(
                                'uid',
                                'title'
                            )
                            ->from('pages')
                            ->where(
                                $queryBuilder->expr()->in($getPagesFromId, [ $row['pages'] ])
                            )
                            ->execute()
                            ->fetchAll();
            $row['pageElements'] = $pageElements;
        }

        $row['recordTitles'] = explode(', ', nl2br(trim(GeneralUtility::fixed_lgd_cs(BackendUtility::getProcessedValue('tt_content', 'records', $row['records'], 0, 0, 0, $row['uid']), 250))));

        if ($row['media'] > 0) {
            if (is_null($this->fileRepository)) {
                $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
                $this->fileRepository = $objectManager->get('TYPO3\\CMS\\Core\\Resource\\FileRepository');
            }
            $mediaElements = $this->fileRepository->findByRelation('tt_content', 'media', $row['uid']);
            $row['mediaElements'] = $mediaElements;
        }

        $view->assignMultiple($row);
        $itemContent .= $view->render();
        $drawItem = false;
    }

    /**
     * @param string $template
     * @return \TYPO3\CMS\Fluid\View\StandaloneView
     */
    protected function initView($template)
    {
        /** @var \TYPO3\CMS\Extbase\Configuration\BackendConfigurationManager $backendConfigurationManager */
        $backendConfigurationManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Configuration\\BackendConfigurationManager');
        $config = $backendConfigurationManager->getTypoScriptSetup()['plugin.']['tx_usersaccassite.'];

        /** @var \TYPO3\CMS\Fluid\View\StandaloneView $view */
        $view = GeneralUtility::makeInstance('TYPO3\\CMS\\Fluid\\View\\StandaloneView');
        $view->setTemplateRootPaths($config['view.']['templateRootPaths.']);
        $view->setPartialRootPaths($config['view.']['partialRootPaths.']);
        $view->setTemplate('BackendPreview/' . ucfirst($template));

        return $view;
    }

    /**
     * @param int $editId
     * @return string
     */
    protected function getBackendEditUrl($editId)
    {
        $urlParameters = [
            'edit' => [
                'tt_content' => [
                    $editId => 'edit'
                ]
            ],
            'returnUrl' => GeneralUtility::getIndpEnv('REQUEST_URI')
        ];
        $url = BackendUtility::getModuleUrl('record_edit', $urlParameters);
        return $url;
    }
}
