<?php
namespace Saccas\Usersaccassite\Domain\Repository;

/***
 *
 * This file is part of the "usersaccassite" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017
 *
 ***/

/**
 * The repository for Sponsors
 */
class SponsorRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    public function findByUids(array $uidList)
    {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);
        $query->matching(
            $query->in('uid', $uidList)
        );
        return $query->execute();
    }
}
