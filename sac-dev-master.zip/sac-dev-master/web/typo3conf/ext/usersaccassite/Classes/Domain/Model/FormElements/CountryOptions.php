<?php
namespace Saccas\Usersaccassite\Domain\Model\FormElements;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\Restriction\FrontendRestrictionContainer;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Form\Domain\Model\FormElements\GenericFormElement;

class CountryOptions extends GenericFormElement
{
    public function setProperty(string $key, $value)
    {
        if ($key === 'keyField') {
            $optionKey = $value;
            $this->setCountries($optionKey);
            return;
        }
        parent::setProperty($key, $value);
    }

    public function setCountries($optionKey)
    {
        $options = [];

        $language_isocode = $this->getTSFE()->sys_language_isocode;

        $valueField = 'cn_short_' . $language_isocode;

        $countries = $this->getCountries($valueField);

        foreach ($countries as $country) {
            $options[$country[$optionKey]] = $country[$valueField];
        }

        $this->setProperty('options', $options);
    }

    protected function getCountries($valueField)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('static_countries');
        $queryBuilder->setRestrictions(GeneralUtility::makeInstance(FrontendRestrictionContainer::class));

        return $queryBuilder
            ->select('*')
            ->from('static_countries')
            ->orderBy($valueField)
            ->execute()
            ->fetchAll();
    }

    private function getTSFE()
    {
        return $GLOBALS['TSFE'];
    }
}
