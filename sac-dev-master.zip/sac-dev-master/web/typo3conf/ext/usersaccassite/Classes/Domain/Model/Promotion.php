<?php
namespace Saccas\Usersaccassite\Domain\Model;

/***
 *
 * This file is part of the "usersaccassite" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017
 *
 ***/

/**
 * Promotion
 */
class Promotion extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * text
     *
     * @var string
     */
    protected $text = '';

    /**
     * linktitle
     *
     * @var string
     */
    protected $linktitle = '';

    /**
     * @return string
     */
    public function getText(): string
    {
        return $this->text;
    }

    /**
     * @param string $text
     */
    public function setText(string $text)
    {
        $this->text = $text;
    }

    /**
     * @return string
     */
    public function getLinktitle(): string
    {
        return $this->linktitle;
    }

    /**
     * @param string $linktitle
     */
    public function setLinktitle(string $linktitle)
    {
        $this->linktitle = $linktitle;
    }

    /**
     * @return string
     */
    public function getLink(): string
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink(string $link)
    {
        $this->link = $link;
    }

    /**
     * link
     *
     * @var string
     */
    protected $link = '';
}
