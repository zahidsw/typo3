<?php
namespace Saccas\Usersaccassite\Domain\Model;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * The domain model of a FrontendUser
 */
class FrontendUser extends \TYPO3\CMS\Extbase\Domain\Model\FrontendUser
{
    /**
     * @var string
     */
    protected $txUsersaccassiteAddress2;

    /**
    * @var int
    */
    protected $txUsersaccassiteContactNumber;

    /**
    * @var string
    */
    protected $txUsersaccassiteGender;

    /**
    * @var string
    */
    protected $txUsersaccassitePhoneCompany;

    /**
    * @var string
    */
    protected $txUsersaccassitePhoneMobile;

    /**
    * @var string
    */
    protected $txUsersaccassitePobox;

    /**
    * @var string
    */
    protected $txUsersaccassiteProfileUrl;

    /**
    * @var string
    */
    protected $txUsersaccassiteState;

    /**
     * @return string
     */
    public function getTxUsersaccassiteAddress2()
    {
        return $this->txUsersaccassiteAddress2;
    }

    /**
     * @param string $txUsersaccassiteAddress2
     */
    public function setTxUsersaccassiteAddress2(string $txUsersaccassiteAddress2)
    {
        $this->txUsersaccassiteAddress2 = $txUsersaccassiteAddress2;
    }

    /**
     * @return int
     */
    public function getTxUsersaccassiteContactNumber()
    {
        return $this->txUsersaccassiteContactNumber;
    }

    /**
     * @param int $txUsersaccassiteContact_number
     */
    public function setTxUsersaccassiteContactNumber(string $txUsersaccassiteContactNumber)
    {
        $this->txUsersaccassiteContactNumber = $txUsersaccassiteContactNumber;
    }

    /**
     * @return string
     */
    public function getTxusersaccassiteGender()
    {
        return $this->txusersaccassiteGender;
    }

    /**
     * @param string $txUsersaccassiteGender
     */
    public function setTxusersaccassiteGender(string $txUsersaccassiteGender)
    {
        $this->txUsersaccassiteGender = $txUsersaccassiteGender;
    }

    /**
     * @return string
     */
    public function getTxUsersaccassitePhoneCompany()
    {
        return $this->txUsersaccassitePhoneCompany;
    }

    /**
     * @param string $txUsersaccassitePhoneCompany
     */
    public function setTxUsersaccassitePhoneCompany(string $txUsersaccassitePhoneCompany)
    {
        $this->txUsersaccassitePhoneCompany = $txUsersaccassitePhoneCompany;
    }

    /**
     * @return string
     */
    public function getTxUsersaccassitePhoneMobile()
    {
        return $this->txUsersaccassitePhoneMobile;
    }

    /**
     * @param string $txUsersaccassitePhoneMobile
     */
    public function setTxUsersaccassitePhoneMobile(string $txUsersaccassitePhoneMobile)
    {
        $this->txUsersaccassitePhoneMobile = $txUsersaccassitePhoneMobile;
    }

    /**
     * @return string
     */
    public function getTxUsersaccassitePobox()
    {
        return $this->txUsersaccassitePobox;
    }

    /**
     * @param string $txUsersaccassitePobox
     */
    public function setTxUsersaccassitePobox(string $txUsersaccassitePobox)
    {
        $this->txUsersaccassitePobox = $txUsersaccassitePobox;
    }

    /**
     * @return string
     */
    public function getTxUsersaccassiteProfileUrl()
    {
        return $this->txUsersaccassiteProfileUrl;
    }

    /**
     * @param string $txUsersaccassiteProfileUrl
     */
    public function setTxUsersaccassiteProfileUrl(string $txUsersaccassiteProfileUrl)
    {
        $this->txUsersaccassiteProfileUrl = $txUsersaccassiteProfileUrl;
    }

    /**
     * @return string
     */
    public function getTxUsersaccassiteState()
    {
        return $this->txUsersaccassiteState;
    }

    /**
     * @param string $txUsersaccassiteState
     */
    public function setTxUsersaccassiteState(string $txUsersaccassiteState)
    {
        $this->txUsersaccassiteState = $txUsersaccassiteState;
    }
}
