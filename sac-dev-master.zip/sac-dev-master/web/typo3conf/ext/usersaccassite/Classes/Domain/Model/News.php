<?php

namespace Saccas\Usersaccassite\Domain\Model;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015 Georg Ringer, montagmorgen.at
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * News
 */
class News extends \GeorgRinger\News\Domain\Model\News
{

    /**
     * @var \Saccas\Usersaccassite\Domain\Model\Address
     * @lazy
     */
    protected $authorTtaddress;

    /**
     * @var string
     */
    protected $subtitle;

    /**
     * @var string
     */
    protected $callToActionTitle;

    /**
     * Stage Fal Media item
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\GeorgRinger\News\Domain\Model\FileReference>
     * @lazy
     */
    protected $stageFalMedia;

    /**
     * Thumbnail Fal Media item
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\GeorgRinger\News\Domain\Model\FileReference>
     * @lazy
     */
    protected $thumbnailFalMedia;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Saccas\Usersaccassite\Domain\Model\Sponsor>
     * @lazy
     */
    protected $txUsersaccassiteSponsor;

    /**
     * @var string
     */
    protected $textBoxHeader;

    /**
     * @var string
     */
    protected $textBoxCopy;

    /**
     * @var string
     */
    protected $textBoxLinktitle;

    /**
     * @var string
     */
    protected $textBoxLink;

    /**
     * @return \Saccas\Usersaccassite\Domain\Model\Address
     */
    public function getAuthorTtaddress()
    {
        return $this->authorTtaddress;
    }

    /**
     * @param \Saccas\Usersaccassite\Domain\Model\Address
     */
    public function setAuthorTtaddress(\Saccas\Usersaccassite\Domain\Model\Address $authorTtaddress)
    {
        $this->authorTtaddress = $authorTtaddress;
    }

    /**
     * Get subtitle
     *
     * @return string
     */
    public function getSubtitle()
    {
        return $this->subtitle;
    }

    /**
     * Set subtitle
     *
     * @param string $subtitle subtitle
     */
    public function setSubtitle($subtitle)
    {
        $this->subtitle = $subtitle;
    }

    /**
     * Get callToActionTitle
     *
     * @return string
     */
    public function getCallToActionTitle()
    {
        return $this->callToActionTitle;
    }

    /**
     * Set callToActionTitle
     *
     * @param string $callToActionTitle callToActionTitle
     */
    public function setCallToActionTitle($callToActionTitle)
    {
        $this->callToActionTitle = $callToActionTitle;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getStageFalMedia()
    {
        if ($this->getSysLanguageUid() > 0) {
            $fileRepository = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Resource\FileRepository::class);
            $fileObjects = $fileRepository->findByRelation('tx_news_domain_model_news', 'stage_fal_media', $this->getVersionedUid());
            return $fileObjects;
        }
        return $this->stageFalMedia;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $thumbnailFalMedia
     */
    public function setThumbnailFalMedia(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $thumbnailFalMedia)
    {
        $this->thumbnailFalMedia = $thumbnailFalMedia;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getThumbnailFalMedia()
    {
        if ($this->getSysLanguageUid() > 0) {
            $fileRepository = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Resource\FileRepository::class);
            $fileObjects = $fileRepository->findByRelation('tx_news_domain_model_news', 'thumbnail_fal_media', $this->getVersionedUid());
            return $fileObjects;
        }
        return $this->thumbnailFalMedia;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $stageFalMedia
     */
    public function setStageFalMedia(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $stageFalMedia)
    {
        $this->stageFalMedia = $stageFalMedia;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Saccas\Usersaccassite\Domain\Model\Sponsor>
     */
    public function getTxUsersaccassiteSponsor()
    {
        return $this->txUsersaccassiteSponsor;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Saccas\Usersaccassite\Domain\Model\Sponsor> $txUsersaccassiteSponsor
     */
    public function setTxUsersaccassiteSponsor(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $txUsersaccassiteSponsor)
    {
        $this->txUsersaccassiteSponsor = $txUsersaccassiteSponsor;
    }

    /**
     * @return mixed
     */
    public function getTextBoxHeader()
    {
        return $this->textBoxHeader;
    }

    /**
     * @param mixed $textBoxHeader
     */
    public function setTextBoxHeader($textBoxHeader)
    {
        $this->textBoxHeader = $textBoxHeader;
    }

    /**
     * @return string
     */
    public function getTextBoxCopy(): string
    {
        return $this->textBoxCopy;
    }

    /**
     * @param string $textBoxCopy
     */
    public function setTextBoxCopy(string $textBoxCopy)
    {
        $this->textBoxCopy = $textBoxCopy;
    }

    /**
     * @return string
     */
    public function getTextBoxLinktitle(): string
    {
        return $this->textBoxLinktitle;
    }

    /**
     * @param string $textBoxLinktitle
     */
    public function setTextBoxLinktitle(string $textBoxLinktitle)
    {
        $this->textBoxLinktitle = $textBoxLinktitle;
    }

    /**
     * @return string
     */
    public function getTextBoxLink(): string
    {
        return $this->textBoxLink;
    }

    /**
     * @param string $textBoxLink
     */
    public function setTextBoxLink(string $textBoxLink)
    {
        $this->textBoxLink = $textBoxLink;
    }

    /**
     * Get parent/main news Uid
     * @return int
     */
    protected function getVersionedUid()
    {
        return $this->_versionedUid;
    }
}
