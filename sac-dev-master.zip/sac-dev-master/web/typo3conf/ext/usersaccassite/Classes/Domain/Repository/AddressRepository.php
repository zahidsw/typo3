<?php

namespace Saccas\Usersaccassite\Domain\Repository;

class AddressRepository extends \TYPO3\TtAddress\Domain\Repository\AddressRepository
{

    /**
     * Initializes the repository.
     */
    public function initializeObject()
    {
        /** @var $querySettings \TYPO3\CMS\Extbase\Persistence\Generic\QuerySettingsInterface */
        $querySettings = $this->objectManager->get(\TYPO3\CMS\Extbase\Persistence\Generic\QuerySettingsInterface::class);
        $querySettings->setRespectStoragePage(false);
        $this->setDefaultQuerySettings($querySettings);
    }

    /**
     * @param array $uids
     * @return array|\TYPO3\CMS\Extbase\Persistence\QueryResultInterface
     */
    public function findByUids(array $uids)
    {
        /** @var \TYPO3\CMS\Extbase\Persistence\QueryInterface $query */
        $query = $this->createQuery();
        $query->matching(
            $query->in('uid', $uids)
        );
        $query->setOrderings($this->orderByField('uid', $uids));

        return $query->execute();
    }

    /**
     * Set the order method
     * Credits: http://blog.teamgeist-medien.de/2014/09/typo3-extbase-repository-find-by-multiple-uids-findbyuids.html
     */
    protected function orderByField($field, $values)
    {
        $orderings = [];
        foreach ($values as $value) {
            $orderings["$field={$value}"] = \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING;
        }
        return $orderings;
    }
}
