<?php
namespace Saccas\Usersaccassite\Domain\Model;

/***
 *
 * This file is part of the "usersaccassite" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017
 *
 ***/

/**
 * Campaign
 */
class Campaign extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * header
     *
     * @var string
     */
    protected $header = '';

    /**
     * subheader
     *
     * @var string
     */
    protected $subheader = '';

    /**
     * header_layout
     *
     * @var int
     */
    protected $header_layout = 3;

    /**
     * link
     *
     * @var string
     */
    protected $link = '';

    /**
     * linktitle
     *
     * @var string
     */
    protected $linktitle = '';

    /**
     * image
     *
     * @var \TYPO3\CMS\Extbase\Domain\Model\FileReference
     * @cascade remove
     */
    protected $image = null;

    /**
     * @return string
     */
    public function getHeader(): string
    {
        return $this->header;
    }

    /**
     * @param string $header
     */
    public function setHeader(string $header)
    {
        $this->header = $header;
    }

    /**
     * @return string
     */
    public function getSubheader(): string
    {
        return $this->subheader;
    }

    /**
     * @param string $subheader
     */
    public function setSubheader(string $subheader)
    {
        $this->subheader = $subheader;
    }

    /**
     * @return int
     */
    public function getHeaderLayout(): int
    {
        return $this->header_layout;
    }

    /**
     * @param int $header_layout
     */
    public function setHeaderLayout(int $header_layout)
    {
        $this->header_layout = $header_layout;
    }

    /**
     * @return string
     */
    public function getLink(): string
    {
        return $this->link;
    }

    /**
     * @param string $link
     */
    public function setLink(string $link)
    {
        $this->link = $link;
    }

    /**
     * @return string
     */
    public function getLinktitle(): string
    {
        return $this->linktitle;
    }

    /**
     * @param string $linktitle
     */
    public function setLinktitle(string $linktitle)
    {
        $this->linktitle = $linktitle;
    }

    /**
     * Returns the image
     *
     * @return \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Sets the image
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $image
     */
    public function setImage(\TYPO3\CMS\Extbase\Domain\Model\FileReference $image)
    {
        $this->image = $image;
    }
}
