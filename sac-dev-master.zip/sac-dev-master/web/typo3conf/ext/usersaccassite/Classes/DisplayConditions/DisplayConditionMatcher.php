<?php
namespace Saccas\Usersaccassite\DisplayConditions;

/**
 * Class DisplayConditionMatcher
 *
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 */
class DisplayConditionMatcher
{

    /**
     * Check if the parent content element has the passed field with the value
     * Returns true, if the filed has the value
     *
     * <displayCond>USER:Saccas\Usersaccassite\DisplayConditions\DisplayConditionMatcher->displayIfParentGridElementContentHasValueForField:FIELD:tx_gridelements_backend_layout:=:layoutAccordions</displayCond>
     *
     * @param array $configuration
     * @param \TYPO3\CMS\Backend\Form\FormDataProvider\EvaluateDisplayConditions $evaluateDisplayConditions
     * @return bool
     */
    public function displayIfParentGridElementContentHasValueForField(array $configuration, $evaluateDisplayConditions = null)
    {
        $result = false;
        if ($configuration['conditionParameters'][0] == 'FIELD') {
            if (isset($configuration['record']['parentRec']['tx_gridelements_container'][0])) {
                $result = static::getDatabaseConnection()->exec_SELECTcountRows(
                    $configuration['conditionParameters'][1],
                    'tt_content',
                    "CType = 'gridelements_pi1' AND " . $configuration['conditionParameters'][1] . ' ' . $configuration['conditionParameters'][2] . " '" . $configuration['conditionParameters'][3] . "' AND uid = " . $configuration['record']['parentRec']['tx_gridelements_container'][0]
                );
            }
        }
        return $result;
    }

    /**
     * Returns the database connection.
     *
     * @return \TYPO3\CMS\Core\Database\DatabaseConnection
     */
    protected static function getDatabaseConnection()
    {
        return $GLOBALS['TYPO3_DB'];
    }
}
