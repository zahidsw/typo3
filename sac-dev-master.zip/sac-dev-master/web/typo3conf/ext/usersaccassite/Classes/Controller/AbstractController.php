<?php
namespace Saccas\Usersaccassite\Controller;

use JFB\Handlebars\Controller\AbstractHandlebarsController;
use JFB\Handlebars\DataProvider\LabelDataProvider;
use JFB\Handlebars\DataProvider\TyposcriptDataProvider;

/*
 * This file is part of the Saccas\Usersaccassite project under GPLv2 or later.
 *
 * For the full copyright and license information, please read the
 * LICENSE.md file that was distributed with this source code.
 */

abstract class AbstractController extends AbstractHandlebarsController
{

    /**
     * Get row from current contentObject (tt_content)
     *
     * @return array
     */
    protected function getRow()
    {
        $cObj = $this->configurationManager->getContentObject();
        return $cObj->data;
    }

    /**
     * Get row from current page (pages, pages_language_overlay)
     *
     * @return array
     */
    protected function getPageRow()
    {
        $cObj = $this->configurationManager->getContentObject();
        return $cObj->parentRecord['data'];
    }

    protected function renderHandlebarView($template, $data)
    {
        $settings = $this->settings['handlebars'];
        $settings = array_merge_recursive($settings, [
            'dataProviders' => [
                LabelDataProvider::class,
                TyposcriptDataProvider::class
            ],
            'templatePath' => $settings['templatesRootPath'] . $template,
            'additionalData' => $data
        ]);

        $this->view->assign('settings', $settings);
    }
}
