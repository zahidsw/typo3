<?php
namespace Saccas\Usersaccassite\Controller;

class LoginController extends AbstractController
{
    /**
     * @var \Saccas\Usersaccassite\Formatter\LoginFormatter
     * @inject
     */
    protected $loginFormatter;

    /**
     * show action
     */
    public function showAction()
    {
        $this->loginFormatter->setControllerContext($this->getControllerContext());

        $data = $this->loginFormatter->format();
        $this->renderHandlebarView('modules/c022_login/c022_login.hbs', $data);
    }
}
