<?php
namespace Saccas\Usersaccassite\Controller;

/***
 *
 * This file is part of the "usersaccassite" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017
 *
 ***/

/**
 * SponsorController
 */
class SponsorController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * sponsorRepository
     *
     * @var \Saccas\Usersaccassite\Domain\Repository\SponsorRepository
     * @inject
     */
    protected $sponsorRepository = null;

    /**
     * action list
     */
    public function listAction()
    {
        $sponsors = $this->sponsorRepository->findAll();
        $this->view->assign('sponsors', $sponsors);
    }
}
