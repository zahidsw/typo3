<?php
namespace Saccas\Usersaccassite\Controller;

class VcardController extends AbstractController
{
    /**
     * @var \Saccas\Usersaccassite\Formatter\VcardFormatter
     * @inject
     */
    protected $vcardFormatter;

    /**
     * show action
     */
    public function showAction()
    {
        $rows = $this->getRow();

        $this->vcardFormatter->setControllerContext($this->getControllerContext());
        $entries = explode(',', $rows['tx_usersaccassite_vcards']);

        foreach ($entries as $entry) {
            $data = $this->vcardFormatter->format($entry);
            if ($data) {
                $vcards[] = [
                    'partial' => 'modules/c023_vcard/c023_vcard',
                    'data' => $data,
                ];
            }
        }
        $dataVcardList = [
            'list' => $vcards,
        ];

        $this->renderHandlebarView('modules/m020_teaser_list/_m020_teaser_list_php.hbs', $dataVcardList);
    }
}
