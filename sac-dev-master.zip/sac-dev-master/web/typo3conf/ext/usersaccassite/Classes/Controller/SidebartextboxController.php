<?php
namespace Saccas\Usersaccassite\Controller;

class SidebartextboxController extends AbstractController
{

    /**
     * @var \Saccas\Usersaccassite\Formatter\LinkArrayFormatter
     * @inject
     */
    protected $linkArrayFormatter;

    /**
     * show action
     */
    public function showAction()
    {
        $rows = $this->getRow();

        $data = [
            'headline' => $rows['header'],
            'headlineTag' => 'h3',
            'copy' => '<p>' . strip_tags($rows['bodytext']) . '</p>',
            'link' => $this->linkArrayFormatter->format($rows['tx_usersaccassite_linktitle'], $rows['tx_usersaccassite_link']),
        ];

        $this->renderHandlebarView('modules/m027_sidebar_text_box/m027_sidebar_text_box.hbs', $data);
    }
}
