<?php
namespace Saccas\Usersaccassite\Controller;

use JFB\Handlebars\Controller\AbstractHandlebarsController;
use TYPO3\CMS\Extbase\Object\Container\Exception\UnknownObjectException;

/**
 * Content Controller
 *
 * @route off
 */
class CTypeSwitchController extends AbstractHandlebarsController
{

    /**
     * Detect controller and forward to showAction based on CType
     * @return string
     */
    public function showAction()
    {
        $cObj = $this->configurationManager->getContentObject();

        $moduleName = str_replace('usersaccassite_', '', $cObj->data['CType']);
        $ctypeName = str_replace('_', '', ucfirst($moduleName));

        try {
            $controller = $this->objectManager->get('Saccas\\Usersaccassite\\Controller\\' . $ctypeName . 'Controller');
        } catch (UnknownObjectException $e) {
            return '<h5>"' . $ctypeName . '" not implemented</h5>';
        }

        $this->forward('show', $ctypeName);
    }
}
