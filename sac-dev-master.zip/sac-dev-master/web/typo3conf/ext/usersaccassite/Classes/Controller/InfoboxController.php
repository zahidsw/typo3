<?php
namespace Saccas\Usersaccassite\Controller;

class InfoboxController extends AbstractController
{
    /**
     * @var \Saccas\Usersaccassite\Formatter\HeaderTagFormatter
     * @inject
     */
    protected $headerTagFormatter;

    /**
     * show action
     */
    public function showAction()
    {
        $rows = $this->getRow();

        $data = [
            'headline' => $rows['header'],
            'headlineTag' => $this->headerTagFormatter->format($rows['header_layout'], $this->settings['defaultHeaderType']),
            'copy' => '<p>' . strip_tags($rows['bodytext']) . '</p>',
        ];

        $this->renderHandlebarView('modules/m005_info_box/m005_info_box.hbs', $data);
    }
}
