<?php
namespace Saccas\Usersaccassite\Controller;

/***
 *
 * This file is part of the "usersaccassite" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2017
 *
 ***/

/**
 * AddressController
 */
class AddressController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * AddressRepository
     *
     * @var Saccas\Usersaccassite\Domain\Repository\AddressRepository
     * @inject
     */
    protected $addressRepository = null;

    /**
     * action list
     */
    public function listAction()
    {
        $addressUids = explode(',', $this->settings['records']);
        $addresses = $this->addressRepository->findByUids($addressUids);
        $this->view->assign('addresses', $addresses);
    }
}
