<?php
namespace Saccas\Usersaccassite\Controller;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

class FeuserController extends AbstractController
{
    /**
     * @var \Saccas\Usersaccassite\Domain\Repository\FrontendUserRepository
     */
    protected $frontendUserRepository;

    /**
    * @var \Saccas\Usersaccassite\Formatter\ImageArrayFormatter
    * @inject
    */
    protected $imageArrayFormatter;

    /**
     * @var \Saccas\Usersaccassite\Formatter\PageUriFormatter
     * @inject
     */
    protected $pageUriFormatter;

    /**
     * Inject the FrontendUserRepository
     *
     * @param \Saccas\Usersaccassite\Domain\Repository\FrontendUserRepository $frontendUserRepository
     */
    public function injectFrontendUserRepository(\Saccas\Usersaccassite\Domain\Repository\FrontendUserRepository $frontendUserRepository)
    {
        $this->frontendUserRepository = $frontendUserRepository;
    }

    private function getCurrentFeUser()
    {
        $tsfe = $this->getTSFE();
        $userId = $tsfe->fe_user->user['uid'];
        if ($userId > 0) {
            $user = $this->frontendUserRepository->findByUid($userId);
        } else {
            $user = null;
        }
        return $user;
    }

    /**
     * show action
     */
    public function showAction()
    {
        $this->pageUriFormatter->setControllerContext($this->getControllerContext());

        /* @var \Saccas\Usersaccassite\Domain\Model\FrontendUser $feuser */
        $feuser = $this->getCurrentFeUser();

        if ($this->request->getFormat() === 'json') {
            if ($feuser === null) {
                $feuser = [
                    '' => ''
                ];
            } else {
                $feuser = $feuser->_getProperties();

                if ($feuser['txUsersaccassiteProfileUrl']) {
                    $feuser['profil_image_url'] = $feuser['txUsersaccassiteProfileUrl'];
                }
                if ($feuser['txUsersaccassiteGender']) {
                    $feuser['gender'] = $feuser['txUsersaccassiteGender'];
                }
                foreach ($feuser as $key => $entry) {
                    $feuser[GeneralUtility::camelCaseToLowerCaseUnderscored($key)] = $feuser[$key];
                }
            }
            header('Content-Type: application/json');
            header('Access-Control-Allow-Origin: localhost');
            $this->view->assign('feuser', $feuser);
            $this->view->setVariablesToRender(['feuser']);
            $this->view->render();
        } else {
            if ($feuser === null) {
                /** @var \TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer $cObj */
                $cObj = GeneralUtility::makeInstance('TYPO3\\CMS\\Frontend\\ContentObject\\ContentObjectRenderer');
                $loginUrl = $cObj->typoLink_URL([
                    'parameter' => $this->settings['pid']['login'],
                    'useCacheHash' => false,
                    'forceAbsoluteUrl' => true,
                    'additionalParams' => '&redirect_url=' . $this->uriBuilder->getRequest()->getRequestUri(),
                ]);
                \TYPO3\CMS\Core\Utility\HttpUtility::redirect($loginUrl, \TYPO3\CMS\Core\Utility\HttpUtility::HTTP_STATUS_403);
            } else {
                $metadataList = [];
                if ($feuser->getTxUsersaccassiteContactNumber() > 0) {
                    $metadataList[] = [
                        'label' => LocalizationUtility::translate('profile.contactNumber.label', 'Usersaccassite', [0 => $feuser->getTxUsersaccassiteContactNumber()]),
                        'icon' => 'profile-badge',
                    ];
                } elseif ($feuser->getEmail()) {
                    $metadataList[] = [
                        'label' => LocalizationUtility::translate('profile.email.label', 'Usersaccassite', [0 => $feuser->getEmail()]),
                        'icon' => 'profile-badge',
                    ];
                }

                $metadataList[] = [
                    'url' => '#hmmmm',
                    'label' => LocalizationUtility::translate('profile.mySections.label', 'Usersaccassite', [0 => 'All, my, sections']),
                    'icon' => 'pin-double',
                ];

                $metadataList[] = [
                    'url' => $this->pageUriFormatter->format($this->settings['pid']['login'], ['logintype' => 'logout']),
                    'label' => LocalizationUtility::translate('profile.lastLoggedIn.label', 'Usersaccassite', [0 => $feuser->getLastlogin()->format(LocalizationUtility::translate('dateFormat', 'Usersaccastranslations'))]),
                    'icon' => 'sign-out',
                ];

                $data = [
                    'headline' => $feuser->getFirstName() . ' ' . $feuser->getLastName(),
                    'headlineTag' => 'h2',
                    'subline' => 'Haupt Sektion',
                    'sublineTag' => 'h4',
                    'img' => $this->imageArrayFormatter->format($feuser->getImage()->current(), [180, 360, 720], 1, 1, 'EXT:usersaccassite/Resources/Public/Icons/logoSAC_192x80.svg', $feuser->getFirstName() . ' ' . $feuser->getLastName()),
                    'metadataList' => $metadataList,
                ];

                $this->renderHandlebarView('modules/m054_profile_header/m054_profile_header.hbs', $data);
            }
        }
    }

    /**
    * @param \TYPO3\CMS\Form\Domain\Model\Renderable\RenderableInterface $renderable
    */
    public function initializeFormElement(\TYPO3\CMS\Form\Domain\Model\Renderable\RenderableInterface $renderable)
    {
        if ($renderable->getUniqueIdentifier() === 'feuserupdateform-firstname') {
            $renderable->setDefaultValue('foo');
        }
    }

    private function getTSFE()
    {
        return $GLOBALS['TSFE'];
    }
}
