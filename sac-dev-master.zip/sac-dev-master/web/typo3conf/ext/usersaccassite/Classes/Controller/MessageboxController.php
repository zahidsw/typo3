<?php
namespace Saccas\Usersaccassite\Controller;

class MessageboxController extends AbstractController
{
    /**
     * @var \Saccas\Usersaccassite\Formatter\HeaderTagFormatter
     * @inject
     */
    protected $headerTagFormatter;

    /**
     * @var \Saccas\Usersaccassite\Formatter\SubHeaderTagFormatter
     * @inject
     */
    protected $subHeaderTagFormatter;

    /**
     * @var \Saccas\Usersaccassite\Formatter\LinkArrayFormatter
     * @inject
     */
    protected $linkArrayFormatter;

    /**
     * show action
     */
    public function showAction()
    {
        $rows = $this->getRow();

        $data = [
            'messageId' => 'message-' . $rows['uid'],
            'headline' => $rows['header'],
            'headlineTag' => $this->headerTagFormatter->format($rows['header_layout'], $this->settings['defaultHeaderType']),
            'subline' => $rows['subheader'],
            'sublineTag' => $this->subHeaderTagFormatter->format($rows['header_layout'], $this->settings['defaultHeaderType']),
            'copy' => '<p>' . strip_tags($rows['bodytext']) . '</p>',
            'link' => $this->linkArrayFormatter->format($rows['tx_usersaccassite_linktitle'], $rows['tx_usersaccassite_link']),
        ];

        $this->renderHandlebarView('modules/m006_message_box/m006_message_box.hbs', $data);
    }
}
