<?php
namespace Saccas\Usersaccassite\DataProcessing;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;
use TYPO3\CMS\Core\Database\RelationHandler;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;
use TYPO3\CMS\Frontend\ContentObject\DataProcessorInterface;

class AbstractCustomCTypeDataProcessor implements DataProcessorInterface
{

    /**
     * @var \GeorgRinger\News\Domain\Repository\NewsRepository
     * @inject
     */
    protected $newsRepository;

    /**
     * objectManager
     *
     * @var \TYPO3\CMS\Extbase\Object\ObjectManager
     */
    protected $objectManager = null;

    /**
     * @var \TYPO3\CMS\Core\Resource\FileRepository
     * @inject
     */
    protected $fileRepository;

    /**
     * Process content object data
     *
     * @param \TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer $cObj The data of the content element or page
     * @param array $contentObjectConfiguration The configuration of Content Object
     * @param array $processorConfiguration The configuration of this processor
     * @param array $processedData Key/value store of processed data (e.g. to be passed to a Fluid View)
     * @return array the processed data as key/value store
     */
    public function process(ContentObjectRenderer $cObj, array $contentObjectConfiguration, array $processorConfiguration, array $processedData)
    {
    }

    protected function getPageImage($page)
    {
        if ((int)$page['tx_csseo_og_image'] > 0) {
            $imageField = 'tx_csseo_og_image';
        } elseif ((int)$page['tx_csseo_tw_image'] > 0) {
            $imageField = 'tx_csseo_tw_image';
        } else {
            $imageField = 'media';
        }
        $fileObject = $this->fileRepository->findByRelation('pages', $imageField, $page['uid']);
        return $fileObject[0];
    }

    protected function getTeaserRecords(ContentObjectRenderer $cObj, array $contentObjectConfiguration, array $processorConfiguration, array $processedData)
    {
        $tables = [
            'pages',
            'tx_news_domain_model_news'
        ];

        /** @var RelationHandler $loadDB*/
        $loadDB = GeneralUtility::makeInstance(RelationHandler::class);
        $loadDB->setFetchAllFields(true);
        $loadDB->start($processedData['data']['records'], implode(',', $tables));
        foreach ($loadDB->tableArray as $table => $v) {
            if (isset($GLOBALS['TCA'][$table])) {
                $loadDB->additionalWhere[$table] = $cObj->enableFields($table);
            }
        }
        $data = $loadDB->getFromDB();
        reset($loadDB->itemArray);
        $itemArray = $loadDB->itemArray;
        $entries = [];
        foreach ($itemArray as $val) {
            $entry = null;
            $row = $data[$val['table']][$val['id']];
            // Perform overlays if necessary (records coming from category collections are already overlaid)
            if ($processedData['data']['records']) {
                // Versioning preview
                $GLOBALS['TSFE']->sys_page->versionOL($val['table'], $row);
                $this->objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
                $this->fileRepository = GeneralUtility::makeInstance(\TYPO3\CMS\Core\Resource\FileRepository::class);
                // Language overlay
                if (is_array($row) && $GLOBALS['TSFE']->sys_language_contentOL) {
                    if ($val['table'] === 'pages') {
                        $row = $GLOBALS['TSFE']->sys_page->getPageOverlay($row);
                        $entry['title'] = $row['title'];
                        $entry['copy'] = $row['abstract'];
                        $entry['linkUrl'] = $cObj->typolink_URL(['parameter' => $row['uid'], 'useCacheHash' => 1]);
                        $entry['img'] = $this->getPageImage($row);

                        $category = $this->getOneCategoryFromPage($row['uid']);
                        $entry['categoryShortcut'] = $category['shortcut'];
                        $entry['categoryTitle'] = $category['title'];
                    } else {
                        $row = $GLOBALS['TSFE']->sys_page->getRecordOverlay($val['table'], $row, $GLOBALS['TSFE']->sys_language_content, $GLOBALS['TSFE']->sys_language_contentOL);
                        if ($val['table'] === 'tx_news_domain_model_news') {
                            if (is_null($this->newsRepository)) {
                                $this->newsRepository = $this->objectManager->get('GeorgRinger\\News\\Domain\\Repository\\NewsRepository');
                            }
                            $news = $this->newsRepository->findByUid($row['uid']);
                            $entry['newsItem'] = $news;
                        }
                    }
                }
            }
            $entries[] = $entry;
        }
        return $entries;
    }

    protected function getOneCategoryFromPage(int $pid)
    {
        /** @var QueryBuilder $queryBuilder */
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('sys_category');
        $category = $queryBuilder
            ->select(
                'sys_category.title',
                'sys_category.shortcut'
            )
            ->from('sys_category_record_mm')
            ->from('sys_category')
            ->where(
                $queryBuilder->expr()->eq(
                    'sys_category_record_mm.uid_local',
                    'sys_category.uid'
                )
            )
            ->andWhere(
                $queryBuilder->expr()->eq(
                    'sys_category_record_mm.tablenames',
                    '"pages"'
                )
            )
            ->andWhere(
                $queryBuilder->expr()->eq(
                    'sys_category_record_mm.fieldname',
                    '"categories"'
                )
            )
            ->andWhere(
                'sys_category.shortcut is not NULL'
            )
            ->andWhere(
                $queryBuilder->expr()->eq(
                    'sys_category_record_mm.uid_foreign',
                    (int)$pid
                )
            )
            ->execute()
            ->fetch();

        return $category;
    }
}
