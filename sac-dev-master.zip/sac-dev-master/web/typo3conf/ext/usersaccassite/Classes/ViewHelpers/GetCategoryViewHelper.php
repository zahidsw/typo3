<?php

namespace Saccas\Usersaccassite\ViewHelpers;

/**
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * ViewHelper that selects one or more categories from the parent category
 *
 * # Example: Basic example
 *
 * <html xmlns:f="http://typo3.org/ns/TYPO3/CMS/Fluid/ViewHelpers"
        xmlns:sac="http://typo3.org/ns/Saccas/Usersaccassite/ViewHelpers"
        data-namespace-typo3-fluid="true"
    >
 *
 * <code>
 *  <sac:getCategory categories="{newsItem.categories}" as="mainCat" type="main">
 *
 *  </sac:getCategory>
 * </code>
 * <output>
 *  the category as string
 * </output>
 *
 * <code>
 *  <sac:getCategory categories="{newsItem.categories}" as="mainCat" type="main">
 *      {v:variable.set(name: 'mainCategory', value: mainCat)}
 *  </sac:getCategory>
 * </code>
 *
 * </html>
 */
class GetCategoryViewHelper extends \TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper
{

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\Generic\LazyObjectStorage $categories
     * @param string $as
     * @param string $type
     * @param int $shortcutId
     * @validate $shortcutId IntegerValidator
     * @return array
     */
    public function render($categories, $as, $type = 'main', $shortcutId = 0)
    {
        if (count($categories) > 0) {
            $tsSettings = $this->templateVariableContainer->get('settings');

            if (in_array($type, array_keys($tsSettings['pid']['category']))) {
                foreach ($categories as $category) {
                    if ($category->getPid() == $tsSettings['pid']['category'][$type]) {
                        $processedContent = $category;
                        $this->templateVariableContainer->add($as, $processedContent);
                        $output = $this->renderChildren();
                        $this->templateVariableContainer->remove($as);
                        return $output;
                    }
                }
            }
        }
        return '';
    }
}
