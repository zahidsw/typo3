<?php

namespace Saccas\Usersaccassite\ViewHelpers\Form;
use TYPO3\CMS\Fluid\Core\ViewHelper\AbstractViewHelper;

/**
 * Returns Error Class if Error in form field
 *
 * @package Saccas
 * @subpackage Usersaccassite
 * @version
 */
class ErrorClassViewHelper extends AbstractViewHelper
{
    /**
     * @param string $property
     * @param string $class Any string for errorclass
     * @return string
     */
    public function render($property, $class = 'has-error')
    {
        $formObjectName = $this->viewHelperVariableContainer->get(\TYPO3\CMS\Fluid\ViewHelpers\FormViewHelper::class, 'formObjectName');
        $key = ($formObjectName . '.' . $property);
        $validationResults = $this->controllerContext->getRequest()->getOriginalRequestMappingResults();
        $errors = $validationResults->getFlattenedErrors();
        if (array_key_exists($key, $errors)) {
            return $class;
        }
        return '';
    }
}
