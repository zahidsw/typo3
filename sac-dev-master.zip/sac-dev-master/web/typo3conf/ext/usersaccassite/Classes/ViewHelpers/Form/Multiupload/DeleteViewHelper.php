<?php

namespace Saccas\Usersaccassite\ViewHelpers\Form\Multiupload;

use Saccas\Usersaccassite\Property\TypeConverter\FileReferenceObjectStorageConverter;

/**
 * This class renders a checkbox that will remove the FileReference from the
 * associated ObjectStorage when unchecked. It may only be used inside of a
 * MultiUploadViewhelper.
 *
 * TODO: Find a better name for this class!
 */
class DeleteViewHelper extends \TYPO3\CMS\Fluid\ViewHelpers\Form\CheckboxViewHelper
{
    /**
     * @var \TYPO3\CMS\Extbase\Security\Cryptography\HashService
     * @inject
     */
    protected $hashService;

    /**
     * Renders the checkbox.
     *
     * @param boolean $checked Specifies that the input element should be preselected
     * @param boolean $multiple
     * @throws \TYPO3\CMS\Fluid\Core\ViewHelper\Exception
     * @return string
     * @api
     */
    public function render()
    {
        if (!$this->arguments['value'] instanceof \TYPO3\CMS\Extbase\Domain\Model\FileReference) {
            throw new \InvalidArgumentException(
                \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate('error.image.fileError',
                    'usersaccassite'), 1421848917);
        }
        $resourcePointerValue = $this->arguments['value']->getUid();

        if ($resourcePointerValue === null) {
            // Newly created file reference which is not persisted yet.
            // Use the file UID instead, but prefix it with "file:" to communicate this to the type converter
            $resourcePointerValue = 'file:' . $this->arguments['value']->getOriginalResource()->getOriginalFile()->getUid();
        }
        $index = $this->viewHelperVariableContainer->get('Saccas\\Usersaccassite\\ViewHelpers\\Form\\Multiupload\\MultiuploadViewHelper',
            'fileReferenceIndex');
        $this->viewHelperVariableContainer->addOrUpdate('Saccas\\Usersaccassite\\ViewHelpers\\Form\\Multiupload\\MultiuploadViewHelper',
            'fileReferenceIndex', ++$index);
        // TODO: Fluid automatically adds the __identity key if the argument to the
        //		 viewhelper is a persisted model, but stripping the key on our own
        //		 is ugly here. Generate the name on ourselves?
        $name = $this->getName();
        $name = (strpos($name, '[__identity]') === false ? $name : substr($name, 0,
                -strlen('[__identity]'))) . '[' . $index . ']';
        $this->registerFieldNameForFormTokenGeneration($name);
        $this->tag->addAttribute('name', $name . '[submittedFile][resourcePointer]');
        $this->tag->getAttribute(multiple);
        $this->tag->addAttribute('multiple', false);
        $this->tag->addAttribute('type', 'checkbox');
        $this->tag->addAttribute('checked', true);
        $this->tag->addAttribute('value', htmlspecialchars($this->hashService->appendHmac((string)$resourcePointerValue)));
        return $this->tag->render();
    }
}
