<?php

namespace Saccas\Usersaccassite\Formatter;

class HeaderTagFormatter extends AbstractFormatter
{

    /**
     * @param int $layout
     * @param int $defaultHeaderType
     * @return array
     */
    public function format(int $layout = 0, int $defaultHeaderType = 2)
    {
        if ($layout === 0) {
            $layout = $defaultHeaderType;
        }
        return 'h' . $layout;
    }
}
