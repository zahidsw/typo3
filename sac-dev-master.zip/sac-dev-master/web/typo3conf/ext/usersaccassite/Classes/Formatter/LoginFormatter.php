<?php
namespace Saccas\Usersaccassite\Formatter;

/**
 * Class LoginFormatter
 */
class LoginFormatter extends AbstractFormatter
{

    /**
     * @var \Saccas\Usersaccassite\Formatter\PageUriFormatter
     * @inject
     */
    protected $pageUriFormatter;

    /**
     * @var \Saccas\Usersaccassite\Formatter\LinkArrayFormatter
     * @inject
     */
    protected $linkArrayFormatter;

    /**
     * @return array
     */
    public function format()
    {
        $this->pageUriFormatter->setControllerContext($this->getControllerContext());
        $this->linkArrayFormatter->setControllerContext($this->getControllerContext());

        $objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
        $settings = $configurationManager->getConfiguration(
            \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS
        );

        $data = $this->getTranslationsItems('usersaccassite', 'header.login');

        $data['headlineTag'] = 'h2';
        $data['sublineTag'] = 'h3';

        $data['inputs']['id'] += [
            'id' => 'header-login-id',
            'name' => 'id',
        ];

        $data['inputs']['password'] += [
            'id' => 'header-login-password',
            'name' => 'password',
        ];

        $data['resetPasswordLink'] = $this->linkArrayFormatter->format($this->getTranslation('usersaccassite', 'header.login.resetPasswordLink.label'), $settings['resetPasswordLinkOrPid']);
        $data['registrationLink'] = $this->linkArrayFormatter->format($this->getTranslation('usersaccassite', 'header.login.registrationLink.label'), $settings['registrationLinkOrPid']);
        $data['registrationLinkMembership'] = $this->linkArrayFormatter->format($this->getTranslation('usersaccassite', 'header.login.registrationLinkMembership.label'), $settings['registrationLinkMembershipOrPid']);

        $data['jsOptions']['postLoginUrl'] = $this->pageUriFormatter->format($settings['postLoginUrl']);

        return $data;
    }
}
