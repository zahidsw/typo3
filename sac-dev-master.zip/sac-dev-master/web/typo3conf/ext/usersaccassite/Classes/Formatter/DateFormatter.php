<?php

namespace Saccas\Usersaccassite\Formatter;

/*
 * This file is part of the JFB/Userjungfrausite project under GPLv2 or later.
 *
 * For the full copyright and license information, please read the
 * LICENSE.md file that was distributed with this source code.
 */

use TYPO3\CMS\Core\Utility\MathUtility;

class DateFormatter extends AbstractFormatter
{

    /**
     * Render the supplied DateTime object as a formatted date.
     * Credits: Heavily inspired by DateViewHelper.php
     *
     * @param mixed $date either an object implementing DateTimeInterface or a string that is accepted by DateTime constructor
     * @param string $format Format String which is taken to format the Date/Time
     * @param mixed $base A base time (an object implementing DateTimeInterface or a string) used if $date is a relative date specification. Defaults to current time.
     * @return string Formatted date

     * @throws \Exception
     */
    public function format($date = null, $format = '', $base = null)
    {
        $base = $base === null ? time() : $base;
        if (is_string($base)) {
            $base = trim($base);
        }

        if ($format === '') {
            $format = $GLOBALS['TYPO3_CONF_VARS']['SYS']['ddmmyy'] ?: 'Y-m-d';
        }

        if ($date === null) {
            return '';
        }

        if (is_string($date)) {
            $date = trim($date);
        }

        if ($date === '') {
            $date = 'now';
        }

        if (!$date instanceof \DateTimeInterface) {
            try {
                $base = $base instanceof \DateTimeInterface ? $base->format('U') : strtotime((MathUtility::canBeInterpretedAsInteger($base) ? '@' : '') . $base);
                $dateTimestamp = strtotime((MathUtility::canBeInterpretedAsInteger($date) ? '@' : '') . $date, $base);
                $date = new \DateTime('@' . $dateTimestamp);
                $date->setTimezone(new \DateTimeZone(date_default_timezone_get()));
            } catch (\Exception $exception) {
                throw new \Exception('"' . $date . '" could not be parsed by \DateTime constructor: ' . $exception->getMessage(), 1494401547);
            }
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $date->format('U'));
        } else {
            return $date->format($format);
        }
    }
}
