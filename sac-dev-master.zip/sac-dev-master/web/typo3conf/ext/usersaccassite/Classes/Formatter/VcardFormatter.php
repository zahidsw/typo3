<?php
namespace Saccas\Usersaccassite\Formatter;

/**
 * Class VcardFormatter
 */
class VcardFormatter extends AbstractFormatter
{
    /**
     * @var \Saccas\Usersaccassite\Domain\Repository\AddressRepository
     * @inject
     */
    protected $addressRepository = null;

    /**
     * @var \Saccas\Usersaccassite\Domain\Repository\FrontendUserRepository
     * @inject
     */
    protected $frontendUserRepository = null;

    /**
     * @var \Saccas\Usersaccassite\Formatter\LinkArrayFormatter
     * @inject
     */
    protected $linkArrayFormatter;

    /**
     * @var \Saccas\Usersaccassite\Formatter\ImageArrayFormatter
     * @inject
     */
    protected $imageArrayFormatter;

    /**
     * @param string $entry Entry could be an int or a string_int like tt_address_12
     * @return array
     */
    public function format($entry)
    {
        $this->imageArrayFormatter->setControllerContext($this->getControllerContext());

        $entryArray = $this->explodeTableUid($entry);

        switch ($entryArray['table']) {
            case 'tt_address':
                $data = $this->getVCardFromTtAddress($entryArray['uid']);
                break;
            case 'fe_users':
                $data = $this->getVCardFromFeUsers($entryArray['uid']);
                break;
            default:
                $data = $this->getVCardFromTtAddress($entryArray['uid']);
        }
        return $data;
    }

    /**
     * @param int $uid
     * @return array
     */
    private function getVCardFromFeUsers(int $uid)
    {
        /** @var \Saccas\Usersaccassite\Domain\Repository\FrontendUserRepository $feuserEntry */
        $feuserEntry = $this->frontendUserRepository->findByUid($uid);

        $socialFieldRows = [
            'email',
            'www',
            'phone',
            'tx_usersaccassite_phone_mobile',
            'tx_usersaccassite_phone_company',
        ];

        $feuserEntryArray = $feuserEntry->_getCleanProperties();

        foreach ($socialFieldRows as $row) {
            $icon = $this->getRightIcon($row);
            $ariaLabel = $row;
            $url = $this->getRightUrl($feuserEntryArray[$row], $icon);
            if ($feuserEntryArray[$row]) {
                $socialList[] =  $this->linkArrayFormatter->format($ariaLabel, $url, 1, $icon);
            }
        }

        if ($feuserEntry->getImage()) {
            $image = $feuserEntry->getImage()->current();
        }

        $feUserData = [
            'headline' => $feuserEntry->getFirstname() . ' ' . $feuserEntry->getLastname(),
            'headlineTag' => 'h3',
            'label' => $feuserEntry->getTitle(),
            'copy' => $feuserEntry->getDescription(),
            'img' => $this->imageArrayFormatter->format($image, [600, 1200]),
            'socialList' => $socialList,
        ];
        return $feUserData;
    }

    /**
     * @param int $uid
     * @return array
     */
    private function getVCardFromTtAddress(int $uid)
    {
        /** @var \Saccas\Usersaccassite\Domain\Model\Address $addressEntry */
        $addressEntry = $this->addressRepository->findByUid($uid);

        $socialFieldRows = [
            'facebook',
            'twitter',
            'linkedin',
            'skype',
            'email',
            'www',
            'phone',
            'mobile',
        ];

        $addressEntryArray = $addressEntry->_getCleanProperties();

        foreach ($socialFieldRows as $row) {
            $icon = $this->getRightIcon($row);
            $ariaLabel = $row;
            $url = $this->getRightUrl($addressEntryArray[$row], $icon);
            if ($addressEntryArray[$row]) {
                $socialList[] =  $this->linkArrayFormatter->format($ariaLabel, $url, 1, $icon);
            }
        }

        if ($addressEntry->getImage()) {
            $image = $addressEntry->getImage()->current();
        }

        $ttaddressData = [
            'headline' => $addressEntry->getMiddleName(),
            'headlineTag' => 'h3',
            'label' => $addressEntry->getTitle(),
            'copy' => $addressEntry->getDescription(),
            'img' => $this->imageArrayFormatter->format($image, [600, 1200]),
            'socialList' => $socialList,
        ];

        return $ttaddressData;
    }

    /**
     * @param string $row
     * @return string
     */
    private function getRightIcon($row)
    {
        switch ($row) {
            case 'www':
                $icon = 'link';
                break;
            case 'email':
                $icon = 'mail';
                break;
            case 'phone':
            case 'mobile':
            case 'tx_usersaccassite_phone_mobile':
            case 'tx_usersaccassite_phone_company':
                $icon = 'phone';
                break;
            default:
                $icon = $row;
        }
        return $icon;
    }

    /**
     * @param string $rowEntry
     * @param string $icon
     * @return string
     */
    private function getRightUrl($rowEntry, $icon)
    {
        $rowEntry = trim($rowEntry);
        switch ($icon) {
            case 'facebook':
                $url = 'https://www.facebook.com' . $rowEntry;
                break;
            case 'instagram':
                $url = 'https://www.instagram.com/' . $rowEntry;
                break;
            case 'skype':
                $url = 'skype:' . $rowEntry . '?call';
                break;
            case 'twitter':
                $url = 'https://www.twitter.com/' . $rowEntry;
                break;
            case 'mail':
                $url = 'mailto:' . $rowEntry;
                break;
            case 'phone':
                $url = 'tel:' . $rowEntry;
                break;
            default:
                $url = $rowEntry;
        }
        return $url;
    }

    /**
     * @param string $tableWithUid
     * @return array
     */
    private function explodeTableUid($tableWithUid)
    {
        $tableWithUidArray = explode('_', $tableWithUid);
        $uid = array_pop($tableWithUidArray);
        $table = implode('_', $tableWithUidArray);
        $entry = [
            'table' => $table,
            'uid' => $uid,
        ];
        return $entry;
    }
}
