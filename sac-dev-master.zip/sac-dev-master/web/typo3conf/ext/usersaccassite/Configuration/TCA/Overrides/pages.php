<?php
defined('TYPO3_MODE') or die();

$newTCAColumns = [
    'tx_usersaccassite_sponsor_disable' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_usersaccassite_sponsor_disable',
        'config' => [
            'type' => 'check',
            'default' => '0',
        ],
    ],
    'tx_usersaccassite_sponsor' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_usersaccassite_sponsor',
        'displayCond' => 'FIELD:tx_usersaccassite_sponsor_disable:=:0',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectMultipleSideBySide',
            'internal_type' => 'db',
            'allowed' => 'tx_usersaccassite_domain_model_sponsor',
            'foreign_table' => 'tx_usersaccassite_domain_model_sponsor',
            'foreign_table_where' => ' AND tx_usersaccassite_domain_model_sponsor.sys_language_uid IN (-1, 0) ORDER BY title',
            'size' => 6,
            'enableMultiSelectFilterTextfield' => true,
            'minitems' => 0,
            'maxitems' => 6,
            'wizards' => [
                'suggest' => [
                    'type' => 'suggest',
                ],
            ],
        ],
    ],
    'author_ttaddress' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.author',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectMultipleSideBySide',
            'internal_type' => 'db',
            'allowed' => 'tt_address',
            'foreign_table' => 'tt_address',
            'foreign_table_where' => ' AND tt_address.sys_language_uid IN (-1, 0) AND tt_address.pid = ###PAGE_TSCONFIG_ID### ORDER By tt_address.last_name ASC, tt_address.first_name ASC',
            'size' => 6,
            'enableMultiSelectFilterTextfield' => true,
            'minitems' => 0,
            'maxitems' => 4,
            'wizards' => [
                'suggest' => [
                    'type' => 'suggest',
                ],
            ],
        ],
    ],
];

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
    'pages',
    $newTCAColumns
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'pages',
    ',
        --div--;LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:pages.tab.tx_usersaccassite_sac_tools, tx_usersaccassite_sponsor_disable, tx_usersaccassite_sponsor, author_ttaddress 
    '
);
