<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

$newTCAColumns =  [
    'tx_usersaccassite_address2' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_address2',
        'exclude' => '1',
        'config' => [
            'type' => 'text',
            'cols' => '20',
            'rows' => '3'
        ]
    ],
    'tx_usersaccassite_contact_number' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_contact_number',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'eval' => 'int,trim',
            'size' => '11',
        ]
    ],
    'tx_usersaccassite_gender' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_gender',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'size' => '20',
        ]
    ],
    'tx_usersaccassite_phone_mobile' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_phone_mobile',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'eval' => 'trim',
            'size' => '20',
            'max' => '20'
        ],
    ],
    'tx_usersaccassite_phone_company' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_phone_company',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'eval' => 'trim',
            'size' => '20',
            'max' => '20'
        ],
    ],
    'tx_usersaccassite_pobox' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_pobox',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'size' => '20',
        ],
    ],
    'tx_usersaccassite_profile_url' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_profile_url',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'size' => '80',
        ],
    ],
    'tx_usersaccassite_state' => [
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:fe_users.tx_usersaccassite_state',
        'exclude' => '1',
        'config' => [
            'type' => 'input',
            'size' => '20',
        ],
    ],
];

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
    'fe_users',
    $newTCAColumns
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_contact_number',
    '',
    'before:username'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_gender',
    '',
    'after:title'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_address2, tx_usersaccassite_pobox',
    '',
    'after:address'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_state',
    '',
    'after:city'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_phone_mobile, tx_usersaccassite_phone_company',
    '',
    'after:telephone'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'fe_users',
    'tx_usersaccassite_profile_url',
    '',
    'after:email'
);
