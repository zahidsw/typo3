<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

// create a new palette without link based on imageoverlayPalette
$GLOBALS['TCA']['sys_file_reference']['palettes']['imageoverlayWithoutLinkPalette'] = [
    'showitem' => '
        title,alternative,--linebreak--,
        crop, description
    ',
];

$fields = [
    'author_ttaddress' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.author',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectMultipleSideBySide',
            'internal_type' => 'db',
            'allowed' => 'tt_address',
            'foreign_table' => 'tt_address',
            'foreign_table_where' => ' AND tt_address.pid = ###PAGE_TSCONFIG_ID### ORDER By tt_address.last_name ASC, tt_address.first_name ASC',
            'size' => 6,
            'enableMultiSelectFilterTextfield' => true,
            'minitems' => 0,
            'maxitems' => 4,
            'wizards' => [
                'suggest' => [
                    'type' => 'suggest',
                ],
            ],
        ],
    ],
    'subtitle' => [
        'exclude' => 1,
        'l10n_mode' => 'noCopy',
        'label' => 'LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.subtitle',
        'config' => [
            'type' => 'input',
            'size' => 60,
        ]
    ],
    'call_to_action_title' => [
        'exclude' => 1,
        'l10n_mode' => 'noCopy',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.calltoactiontitle',
        'config' => [
            'type' => 'input',
            'size' => 60,
        ]
    ],
    'thumbnail_fal_media' => [
        'exclude' => 1,
        'displayCond' => 'FIELD:sys_language_uid:=:0',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_news_domain_model_news.thumbnail_fal_media',
        'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
            'thumbnail_fal_media',
            [
                'minitems' => 0,
                'maxitems' => 1,
                'foreign_match_fields' => [
                    'fieldname' => 'thumbnail_fal_media',
                    'tablenames' => 'tx_news_domain_model_news',
                    'table_local' => 'sys_file',
                ],
                'foreign_types' => [
                    '0' => [
                        'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayWithoutLinkPalette,
                            --palette--;;filePalette
                        '
                    ],
                    \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                        'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayWithoutLinkPalette,
                            --palette--;;filePalette
                        '
                    ],
                ],
                'overrideChildTca' => [
                    'types' => [
                        '0' => [
                            'showitem' => '
                                --palette--;LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                                --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => '
                                --palette--;LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                                --palette--;;filePalette'
                        ],
                    ],
                ],
            ],
            $GLOBALS['TYPO3_CONF_VARS']['GFX']['imagefile_ext']
        )
    ],
    'stage_fal_media' => [
        'exclude' => 1,
        'displayCond' => 'FIELD:sys_language_uid:=:0',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_news_domain_model_news.stage_fal_media',
        'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
            'stage_fal_media',
            [
                'minitems' => 0,
                'maxitems' => 1,
                'foreign_match_fields' => [
                    'fieldname' => 'stage_fal_media',
                    'tablenames' => 'tx_news_domain_model_news',
                    'table_local' => 'sys_file',
                ],
                'foreign_types' => [
                    '0' => [
                        'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayWithoutLinkPalette,
                            --palette--;;filePalette
                        '
                    ],
                    \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                        'showitem' => '
                            --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayWithoutLinkPalette,
                            --palette--;;filePalette
                        '
                    ],
                ],
                'overrideChildTca' => [
                    'types' => [
                        '0' => [
                            'showitem' => '
                                --palette--;LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                                --palette--;;filePalette'
                        ],
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => '
                                --palette--;LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette,
                                --palette--;;filePalette'
                        ],
                    ],
                ],
            ],
            $GLOBALS['TYPO3_CONF_VARS']['GFX']['imagefile_ext']
        )
    ],
    'tx_usersaccassite_sponsor' => [
        'exclude' => 1,
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_usersaccassite_sponsor',
        'config' => [
            'type' => 'select',
            'renderType' => 'selectMultipleSideBySide',
            'internal_type' => 'db',
            'allowed' => 'tx_usersaccassite_domain_model_sponsor',
            'foreign_table' => 'tx_usersaccassite_domain_model_sponsor',
            'foreign_table_where' => ' AND tx_usersaccassite_domain_model_sponsor.sys_language_uid IN (-1, 0) ORDER BY title',
            'size' => 6,
            'maxitems' => 6,
            'wizards' => [
                'suggest' => [
                    'type' => 'suggest',
                ],
            ],
        ],
    ],
    'text_box_header' => [
        'exclude' => '1',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.title',
        'config' => [
            'type' => 'input',
        ]
    ],
    'text_box_copy' => [
        'exclude' => '1',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.text',
        'config' => [
            'type' => 'text',
        ],
    ],
    'text_box_linktitle' => [
        'exclude' => '1',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.linktitle',
        'config' => [
            'type' => 'input',
        ],
    ],
    'text_box_link' => [
        'config' => [
            'type' => 'input',
            'wizards' => [
                '_PADDING' => '2',
                'link' => [
                    'type' => 'popup',
                    'title' => 'Link',
                    'icon' => 'actions-wizard-link',
                    'module' => [
                        'name' => 'wizard_link',
                        'urlParameters' => [
                            'mode' => 'wizard',
                        ],
                    ],
                    'JSopenParams' => 'height=300,width=500,status=0,menubar=0,scrollbars=0',
                    'params' => [
                        'blindLinkOptions' => 'mail,folder',
                    ],
                ],
            ],
        ],
        'exclude' => '1',
        'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.link',
    ],
];

$GLOBALS['TCA']['tx_news_domain_model_news']['palettes']['palette_stage'] = [
    'showitem' => 'stage_fal_media,thumbnail_fal_media'
];

$GLOBALS['TCA']['tx_news_domain_model_news']['palettes']['palette_text_box'] = [
    'showitem' => 'text_box_header,text_box_copy,text_box_linktitle,text_box_link'
];

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('tx_news_domain_model_news', $fields);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    'author_ttaddress',
    '',
    'after:description'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    '--palette--;;palette_stage',
    '',
    'before:teaser'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    'subtitle',
    '',
    'after:title'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    'call_to_action_title',
    '',
    'after:teaser'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    '--palette--;Text box;palette_text_box',
    '',
    'before:related'
);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
    'tx_news_domain_model_news',
    'tx_usersaccassite_sponsor',
    '',
    'after:related_from'
);

// override default tx_news configs
$GLOBALS['TCA']['tx_news_domain_model_news']['ctrl']['requestUpdate'] .= ',istopnews';
$GLOBALS['TCA']['tx_news_domain_model_news']['columns']['categories']['displayCond'] = 'FIELD:sys_language_uid:=:0';
$GLOBALS['TCA']['tx_news_domain_model_news']['columns']['categories']['config']['size'] = 30;
$GLOBALS['TCA']['tx_news_domain_model_news']['columns']['categories']['config']['treeConfig']['appearance']['width'] = '400';
$GLOBALS['TCA']['tx_news_domain_model_news']['columns']['istopnews']['displayCond'] = 'FIELD:sys_language_uid:=:0';
$GLOBALS['TCA']['tx_news_domain_model_news']['columns']['istopnews']['config']['behaviour']['allowLanguageSynchronization'] = true;
