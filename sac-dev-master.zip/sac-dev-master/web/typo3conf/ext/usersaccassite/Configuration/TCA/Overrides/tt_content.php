<?php
defined('TYPO3_MODE') or die();

if (!function_exists('addNewCTypeWithFields')) {
    function addNewCTypeWithFields($ctypeName, $showitems = '')
    {
        $module = 'usersaccassite_' . strtolower($ctypeName);

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPlugin(
            [
                'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db_new_content_el.xlf:tt_content.CType.' . $module,
                $module,
                \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::siteRelPath('usersaccassite') . 'ext_icon.svg'
            ],
            'CType',
            'usersaccassite'
        );

        // Configure the default backend fields for the content element
        $GLOBALS['TCA']['tt_content']['types'][$module] = [
            'showitem' => '
                --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xml:palette.general;general,
                ' . $showitems . ($showitems ? ',' : '') . '
            --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xml:tabs.access,
                --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xml:palette.visibility;visibility,
                --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xml:palette.access;access,
            --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xml:tabs.extended,
            --div--;LLL:EXT:gridelements/Resources/Private/Language/locallang_db.xlf:gridElements,tx_gridelements_container,tx_gridelements_columns
        '];
    }
}

call_user_func(function () {

    /*
     * NEW tt_content fields
     */
    $newColumns = [
        'tx_usersaccassite_linktitle' => [
            'config' => [
                'type' => 'input',
            ],
            'exclude' => '1',
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.linktitle',
        ],
        'tx_usersaccassite_link' => [
            'config' => [
                'type' => 'input',
                'renderType' => 'inputLink',
                'wizards' => [
                    '_PADDING' => '2',
                    'link' => [
                        'type' => 'popup',
                        'title' => 'Link',
                        'icon' => 'actions-wizard-link',
                        'module' => [
                            'name' => 'wizard_link',
                            'urlParameters' => [
                                'mode' => 'wizard',
                            ],
                        ],
                        'JSopenParams' => 'height=300,width=500,status=0,menubar=0,scrollbars=0',
                        'params' => [
                            'blindLinkOptions' => 'mail,folder',
                        ],
                    ],
                ],
            ],
            'exclude' => '1',
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.link',
        ],
        'tx_usersaccassite_sponsor' => [
            'exclude' => 1,
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tx_usersaccassite_sponsor',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectMultipleSideBySide',
                'internal_type' => 'db',
                'allowed' => 'tx_usersaccassite_domain_model_sponsor',
                'foreign_table' => 'tx_usersaccassite_domain_model_sponsor',
                'foreign_table_where' => ' AND tx_usersaccassite_domain_model_sponsor.sys_language_uid IN (-1, 0) ORDER BY title',
                'size' => 6,
                'maxitems' => 6,
                'wizards' => [
                    'suggest' => [
                        'type' => 'suggest',
                    ],
                ],
            ],
        ],
        'tx_usersaccassite_vcards' => [
            'exclude' => 1,
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:common.vcard',
            'config' => [
                'type' => 'group',
                'internal_type' => 'db',
                'allowed' => 'tt_address, fe_users',
                'foreign_table' => 'tt_address, fe_users',
                'size' => 6,
                'enableMultiSelectFilterTextfield' => true,
                'minitems' => 0,
                'maxitems' => 12,
                'wizards' => [
                    'suggest' => [
                        'type' => 'suggest',
                    ],
                ],
            ],
        ],
        'tx_usersaccassite_mediaautoplay' => [
            'config' => [
                'type' => 'check',
            ],
            'exclude' => '1',
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tt_content.tx_usersaccassite_mediaautoplay',
        ],
        'tx_usersaccassite_mediainline' => [
            'config' => [
                'type' => 'check',
            ],
            'exclude' => '1',
            'label' => 'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:tt_content.tx_usersaccassite_mediainline',
        ],
    ];
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('tt_content', $newColumns);

    /*
     * NEW CTypes
     */

    // new CType Section
    $GLOBALS['TCA']['tt_content']['columns']['CType']['config']['items'][] = [
        'LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db_new_content_el.xlf:tt_content.CType.div._usersaccassite_',
        '--div--',
    ];

    // new CType Elements
    addNewCTypeWithFields('feuser', 'header,header_layout');
    addNewCTypeWithFields('feuserupdateform', 'header,header_layout');
    addNewCTypeWithFields('infobox', 'header,header_layout,bodytext');
    addNewCTypeWithFields('media', 'header,header_layout,subheader,layout,media,tx_usersaccassite_mediaautoplay,tx_usersaccassite_mediainline');
    addNewCTypeWithFields('menu_pills', 'header,header_layout,subheader,pages');
    addNewCTypeWithFields('menu_pills_pages', 'header,header_layout,subheader,pages');
    addNewCTypeWithFields('menu_tabs', 'header,header_layout,subheader,pages');
    addNewCTypeWithFields('menu_tabs_pages', 'header,header_layout,subheader,pages');
    addNewCTypeWithFields('menu_teaser_content_records', 'header,header_layout,subheader,records');
    addNewCTypeWithFields('menu_teaser_related_records', 'header,header_layout,subheader,records');
    addNewCTypeWithFields('messagebox', 'header,subheader,bodytext,tx_usersaccassite_linktitle,tx_usersaccassite_link');
    addNewCTypeWithFields('sidebar_text_box', 'header,bodytext,tx_usersaccassite_linktitle,tx_usersaccassite_link');
    addNewCTypeWithFields('sponsor', 'header,header_layout,subheader,tx_usersaccassite_sponsor');
    addNewCTypeWithFields('vcard', 'header,header_layout,subheader,tx_usersaccassite_vcards');

    // columnsOverrides for cTypes
    $GLOBALS['TCA']['tt_content']['types']['usersaccassite_menu_teaser_content_records'] += [
        'columnsOverrides' => [
            'records' => [
                'config' => [
                    'allowed' => 'pages,tx_news_domain_model_news',
                ],
            ],
        ],
    ];

    $GLOBALS['TCA']['tt_content']['types']['usersaccassite_menu_teaser_related_records'] += [
        'columnsOverrides' => [
            'records' => [
                'config' => [
                    'allowed' => 'pages,tx_news_domain_model_news',
                ],
            ],
        ],
    ];

    // force header to required to force the hidden = 100
    foreach ($GLOBALS['TCA']['tt_content']['types'] as $cTypeKey => $cType) {
        $GLOBALS['TCA']['tt_content']['types'][$cTypeKey]['columnsOverrides']['header']['config']['eval'] = 'required';
    }
});
