# In ext_localconf.php registered preset.
RTE.default.preset = saccas

# Preset for tt_content textmedia
RTE.tt_content.types.textmedia.bodytext.preset = saccas

# Preset for ext:tx_news
RTE.config.tx_news_domain_model_news.bodytext.preset = saccas
