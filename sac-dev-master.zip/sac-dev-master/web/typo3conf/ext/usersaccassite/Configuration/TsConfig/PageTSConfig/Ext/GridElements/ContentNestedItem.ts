tx_gridelements {
  setup {
    contentNestedItem {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.contentNestedItem.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.contentNestedItem.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/ContentNestedItem.gif
      config {
        colCount = 1
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.contentNestedItem.title
              colPos = 300
            }
          }
        }
      }
      flexformDS = FILE:EXT:usersaccassite/Configuration/FlexForm/Ext/GridElements/ContentNestedItem.xml
    }
  }
}
