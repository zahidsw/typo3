tx_gridelements {
  setup {
    layoutAccordions {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutAccordions.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutAccordions.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/LayoutAccordions.gif
      config {
        colCount = 1
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutAccordions.title
              colPos = 301
              allowed = gridelements_pi1
              allowedGridTypes = contentNestedItem
            }
          }
        }
      }
      flexformDS = FILE:EXT:usersaccassite/Configuration/FlexForm/Ext/GridElements/LayoutAccordions.xml
    }
  }
}
