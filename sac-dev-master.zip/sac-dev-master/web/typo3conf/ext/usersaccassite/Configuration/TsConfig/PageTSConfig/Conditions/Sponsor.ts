[PIDinRootline = 243]

  mod.web_list.allowedNewTables = pages_language_overlay, tx_usersaccassite_domain_model_sponsor

[GLOBAL]
