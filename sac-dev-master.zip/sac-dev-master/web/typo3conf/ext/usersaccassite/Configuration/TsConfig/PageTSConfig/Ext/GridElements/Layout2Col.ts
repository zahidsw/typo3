tx_gridelements {
  setup {
    layout2col {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layout2col.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layout2col.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/Layout2Col.gif
      topLevelLayout = 1
      config {
        colCount = 3
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col1
              colPos = 201
              colspan = 2
            }
            2 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col2
              colPos = 202
            }
          }
        }
      }
    }
  }
}
