tx_gridelements {
  setup {
    layout1col {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layout1col.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layout1col.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/Layout1Col.gif
      topLevelLayout = 1
      config {
        colCount = 1
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col1
              colPos = 201
            }
          }
        }
      }
    }
  }
}
