TCEFORM {
  tx_powermail_domain_model_form {
    css {
      removeItems = layout1, layout2, layout3
      addItems {
        horizontal = horizontal
      }
    }
  }
  tx_powermail_domain_model_page < .tx_powermail_domain_model_form
  tx_powermail_domain_model_field < .tx_powermail_domain_model_form
}
