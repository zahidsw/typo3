[PIDinRootline = 66]

  mod.web_list.allowedNewTables = pages_language_overlay, tx_news_domain_model_news

  TCEFORM.tx_news_domain_model_news {
    is_event.disabled = 1
  }

  TCEFORM.tt_content.CType.removeItems = gridelements_pi1
[GLOBAL]
