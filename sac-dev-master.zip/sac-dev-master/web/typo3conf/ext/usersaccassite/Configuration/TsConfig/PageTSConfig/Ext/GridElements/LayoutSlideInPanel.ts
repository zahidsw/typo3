tx_gridelements {
  setup {
    layoutSlideInPanel {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutSlideInPanel.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutSlideInPanel.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/Content3Col.gif
      config {
        colCount = 3
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col1
              colPos = 501
            }
            2 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col2
              colPos = 502
            }
            3 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col3
              colPos = 503
            }
          }
        }
      }
      flexformDS = FILE:EXT:usersaccassite/Configuration/FlexForm/Ext/GridElements/LayoutSlideInPanel.xml
    }
  }
}
