tx_news.module {
  preselect {

  }
  columns = datetime, istopnews, is_event, categories, tags
  defaultPid {
    tx_news_domain_model_news = 66
    tx_news_domain_model_tag = 41
  }
  redirectToPageOnStart = 66
  allowedPage = 66
}

TCEFORM.tx_news_domain_model_news {
  author.disabled = 1
  author_email.disabled = 1
  author_ttaddress.PAGE_TSCONFIG_ID = 357
}
