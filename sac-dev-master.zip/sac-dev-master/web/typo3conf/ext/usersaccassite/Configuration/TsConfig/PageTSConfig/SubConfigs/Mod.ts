mod {
  SHARED {
    defaultLanguageFlag = de
    defaultLanguageLabel = Deutsch
  }
  web_layout {
    BackendLayouts {
      page {
        title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.page.title
        config {
          backend_layout {
            colCount = 1
            rowCount = 1
            rows {
              1 {
                columns {
                  1 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.mainContent
                    colPos = 0
                  }
                }
              }
            }
          }
        }
        icon = EXT:usersaccassite/Resources/Public/Icons/Page/Page.svg
      }
      account < .page
      account {
        title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.account.title
        icon = EXT:usersaccassite/Resources/Public/Icons/Page/Account.svg
      }
      pageDetail < .page
      pageDetail {
        title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.pageDetail.title
        icon = EXT:usersaccassite/Resources/Public/Icons/Page/PageDetail.svg
      }
      pageRightColumn {
        title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.pageRightColumn.title
        config {
          backend_layout {
            colCount = 3
            rowCount = 3
            rows {
              1 {
                columns {
                  1 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.topContent
                    colspan = 3
                    colPos = 1
                  }
                }
              }
              2{
                columns {
                  1 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.mainContent
                    colspan = 2
                    colPos = 0
                  }
                  2 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.rightContent
                    colPos = 2
                  }
                }
              }
              3 {
                columns {
                  1 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.bottomContent
                    colspan = 3
                    colPos = 3
                  }
                }
              }
            }
          }
        }
        icon = EXT:usersaccassite/Resources/Public/Icons/Page/PageRightColumn.svg
      }
      pageRoute {
        title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.pageRoute.title
        config {
          backend_layout {
            colCount = 1
            rowCount = 1
            rows {
              1 {
                columns {
                  1 {
                    name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mod.web_layout.backendLayouts.common.mainContent
                    colPos = 0
                  }
                }
              }
            }
          }
        }
        icon = EXT:usersaccassite/Resources/Public/Icons/Page/PageRoute.svg
      }
    }
  }
  wizards.newContentElement.wizardItems.common.elements {
    table.tt_content_defValues.table_header_position = 1
  }
}
