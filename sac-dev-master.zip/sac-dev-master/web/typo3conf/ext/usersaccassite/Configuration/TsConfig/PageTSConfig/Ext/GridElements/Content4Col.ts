tx_gridelements {
  setup {
    content4col {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.content4col.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.content4col.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/Content4Col.gif
      config {
        colCount = 4
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col1
              colPos = 101
            }
            2 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col2
              colPos = 102
            }
            3 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col3
              colPos = 103
            }
            4 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col4
              colPos = 104
            }
          }
        }
      }
    }
  }
}
