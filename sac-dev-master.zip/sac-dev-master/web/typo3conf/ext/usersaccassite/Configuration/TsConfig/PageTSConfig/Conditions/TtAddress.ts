[PIDinRootline = 243, 255]

  mod.web_list.allowedNewTables = pages_language_overlay, tt_address
  TCEFORM.tt_address {
  }

[GLOBAL]
