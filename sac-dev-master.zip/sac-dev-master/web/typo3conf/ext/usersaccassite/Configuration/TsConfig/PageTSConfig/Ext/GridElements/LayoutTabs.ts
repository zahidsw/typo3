tx_gridelements {
  setup {
    layoutTabs {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutTabs.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutTabs.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/LayoutTabs.gif
      config {
        colCount = 1
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.layoutTabs.title
              colPos = 302
              allowed = gridelements_pi1
              allowedGridTypes = contentNestedItem
            }
          }
        }
      }
    }
  }
}
