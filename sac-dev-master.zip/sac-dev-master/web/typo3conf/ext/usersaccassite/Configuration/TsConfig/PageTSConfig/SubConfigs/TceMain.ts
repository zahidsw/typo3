TCEMAIN.permissions  {
   groupid = 4
   owner = show, edit, delete, new, editcontent
   group = show, edit, delete, new, editcontent
}
