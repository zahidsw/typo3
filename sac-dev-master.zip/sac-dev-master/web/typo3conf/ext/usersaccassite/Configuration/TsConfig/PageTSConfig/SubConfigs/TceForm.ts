TCEFORM {
  pages {
    author.disabled = 1
    author_email.disabled = 1
    lastUpdated.disabled = 1
    newUntil.disabled = 1
    url_scheme.disabled = 1
    author_ttaddress.PAGE_TSCONFIG_ID = 357
    media.config.maxitems = 1
  }
  tt_content {
    header_layout {
      removeItems = 1,2,5
      altLabels {
        0 = H2 (Default)
        3 = H3
        4 = H4
      }
      types {
        usersaccassite_feuser {
          keepItems = 100
          removeItems = 0,3,4
        }
      }
    }
    header_position.disabled = 1
    header_link.disabled = 1

    layout.disabled = 1
    frame_class.disabled = 1
    space_before_class.disabled = 1
    space_after_class.disabled = 1
    linkToTop.disabled = 1

    date.disabled = 1
    image_zoom.disabled = 1
    imagewidth.disabled = 1
    imageheight.disabled = 1
    imageborder.disabled = 1
    imageorient.disabled = 1
    imagecols.disabled = 1

    filelink_size.disabled = 1
    uploads_description.disabled = 1
    uploads_type.disabled = 1
    rowDescription.disabled = 1

    # default TYPO3
    CType.keepItems (
      form_formframework,
      header,
      text,
      table,
      list,
      login,
      shortcut,
      script,
      html,
      uploads,
      default
    )

    # extensions
    CType.keepItems := addToList(gridelements_pi1)

    # usersaccasssite
    CType.keepItems := addToList(usersaccassite_feuser)
    CType.keepItems := addToList(usersaccassite_feuserupdateform)
    CType.keepItems := addToList(usersaccassite_infobox)
    CType.keepItems := addToList(usersaccassite_media)
    CType.keepItems := addToList(usersaccassite_menu_pills)
    CType.keepItems := addToList(usersaccassite_menu_pills_pages)
    CType.keepItems := addToList(usersaccassite_menu_tabs)
    CType.keepItems := addToList(usersaccassite_menu_tabs_pages)
    CType.keepItems := addToList(usersaccassite_menu_teaser_content_records)
    CType.keepItems := addToList(usersaccassite_menu_teaser_related_records)
    CType.keepItems := addToList(usersaccassite_messagebox)
    CType.keepItems := addToList(usersaccassite_sidebar_text_box)
    CType.keepItems := addToList(usersaccassite_sponsor)
    CType.keepItems := addToList(usersaccassite_vcard)
  }

  sys_file_reference.crop.config.cropVariants {
    default {
      title = LLL:EXT:lang/Resources/Private/Language/locallang_wizards.xlf:imwizard.crop_variant.default
      selectedRatio = 16:10
      allowedAspectRatios {
        16:10 {
          title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:sys_file_reference.ratio.16_10
          value = 1.6
        }
        1:1 {
          title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:sys_file_reference.ratio.1_1
          value = 1
        }
        69:20 {
          title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db.xlf:sys_file_reference.ratio.69_20
          value = 3.45
        }
      }
      cropArea {
        x = 0.0
        y = 0.0
        width = 1.0
        height = 1.0
      }
    }
  }
}
