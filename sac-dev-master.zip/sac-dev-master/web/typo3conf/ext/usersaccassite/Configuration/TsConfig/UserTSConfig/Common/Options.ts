options {
	clearCache.all = 1
	clearCache.pages = 1
}