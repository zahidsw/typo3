tx_gridelements {
  setup {
    content3col {
      title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.content3col.title
      description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.content3col.description
      icon = EXT:usersaccassite/Resources/Public/Icons/Ext/GridElements/Content3Col.gif
      config {
        colCount = 3
        rowCount = 1
        rows.1 {
          columns {
            1 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col1
              colPos = 101
            }
            2 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col2
              colPos = 102
            }
            3 {
              name = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:tx_gridelements.celayout.col3
              colPos = 103
            }
          }
        }
      }
    }
  }
}
