<INCLUDE_TYPOSCRIPT: source="FILE:EXT:form/Configuration/TypoScript/setup.txt">

plugin.tx_form {
  settings {
    yamlConfigurations {
      # register your own additional configuration
      # choose a number higher than 30 (below is reserved)
      100 = EXT:usersaccassite/Configuration/Yaml/Form/CustomFormSetup.yaml
      101 = EXT:usersaccassite/Configuration/Yaml/Form/Forms/Feuserupdateform.yaml
    }
  }
}

module.tx_form {
  settings {
    yamlConfigurations {
      100 = EXT:usersaccassite/Configuration/Yaml/Form/CustomFormSetup.yaml
      101 = EXT:usersaccassite/Configuration/Yaml/Form/Forms/Feuserupdateform.yaml
    }
  }
}
