plugin.tx_falsecuredownload {
  view {
    templateRootPaths.0 = EXT:fal_securedownload/Resources/Private/Templates/
    templateRootPaths.10 = EXT:usersaccassite/Resources/Private/Ext/Fal_Securedownload/Templates/
    partialRootPaths.0 = EXT:fal_securedownload/Resources/Private/Partials/
    partialRootPaths.10 = EXT:usersaccassite/Resources/Private/Ext/Fal_Securedownload/Partials/
    layoutRootPaths.0 = EXT:fal_securedownload/Resources/Private/Layouts/
    layoutRootPaths.10 = EXT:usersaccassite/Resources/Private/Ext/Fal_Securedownload/Layouts/
  }
}
