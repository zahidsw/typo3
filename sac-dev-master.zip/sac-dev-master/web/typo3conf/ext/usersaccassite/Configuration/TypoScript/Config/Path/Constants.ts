PATH {
  productionMinifiedPostfix = .min
  public = typo3conf/ext/usersaccassite/Resources/Public/
  private = typo3conf/ext/usersaccassite/Resources/Private/
  stylesheets = assets/css/
  scripts = assets/js/
  media = assets/media/
  default {
    image = Images/Defaults/
  }
}
