lib.page.menu {
  lang = HMENU
  lang {
    special = language
    special.value = {$site.lang.uids}

    addQueryString = 1
    addQueryString.exclude = L,id,no_cache,tx_usersaccas2020_sac2020|controller
    addQueryString.method = GET
    useCacheHash = 1
    1 = TMENU
    1.noBlur = 1
    1 {
      wrap = <ul class="m-navigation-panel__language-switch o-ui-list">|<li class="m-navigation-panel__language-switch-item"></li><li class="m-navigation-panel__language-switch-item"></li><li class="m-navigation-panel__language-switch-item"></li></ul>
      NO = 1
      NO {
        allWrap = <li class="m-navigation-panel__language-switch-item">|</li>
        stdWrap.setCurrent = {$site.lang.labels}
        stdWrap.current = 1
        ATagTitle = {$site.lang.titleLabels}
        ATagParams = {$site.lang.titleLabels}
        ATagParams.wrap = class="c-button c-button--select c-button--block" aria-label="|"
      }
      ACT < .NO
      ACT {
        allWrap = <li class="m-navigation-panel__language-switch-item is-active">|</li>
      }
      USERDEF1 < .NO
      USERDEF1 {
        doNotLinkIt = 1
        allWrap >
        stdWrap.setCurrent =
      }
    }
  }
  langFooter < .lang
  langFooter {
    1 {
      wrap = <ul class="m-footer__language-switch o-ui-list fs-copy-note-bold">|</ul>
      NO {
        allWrap = <li class="m-footer__language-switch-item">|</li>
        ATagParams = {$site.lang.titleLabels}
        ATagParams.wrap = class="c-button-text" aria-label="|"
      }
      ACT < .NO
      ACT.allWrap = <li class="m-footer__language-switch-item is-active">|</li>
    }
  }
}
