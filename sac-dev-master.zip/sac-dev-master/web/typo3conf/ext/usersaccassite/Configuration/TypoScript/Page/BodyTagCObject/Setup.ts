page {
	bodyTagCObject = COA
	bodyTagCObject {
		wrap = <body |>

		# body class
		10 = COA
		10 {
			# add class to specific backend_layout
		  10 = TEXT
			10 {
				value = l-sso
				if.isInList.field = backend_layout
				if.value = pagets__account
				stdWrap.noTrimWrap = || |
			}

			# current layout
			20 = TEXT
			20 {
				value.data = levelfield:-1, backend_layout_next_level, slide
				value.override.field = backend_layout
				stdWrap.noTrimWrap = || |
			}

			50 = TEXT
			50.value = lang{TSFE:sys_language_uid} type{TSFE:type} uid{TSFE:id}
			50.insertData = 1

			stdWrap.noTrimWrap = | class="|"|
		}

		20 = TEXT
		20 {
			value.field = uid
			stdWrap.noTrimWrap = | data-uid="|"|
		}

		30 = HMENU
		30 {
			special = rootline
			special.range = 0|-1
			includeNotInMenu = 1
			stdWrap.noTrimWrap = | data-rootline="|"|
			1 = TMENU
			1 {
				noBlur = 1
				NO = 1
				NO {
					wrapItemAndSub = |/ |*| |/ |*| |
					linkWrap = |
					ATagBeforeWrap = 0
					doNotLinkIt = 1
					stdWrap.htmlSpecialChars = 0
					stdWrap.cObject = COA
					stdWrap.cObject {
						10 = TEXT
						10 {
							field = uid
						}
					}
				}
			}
		}
	}
}
