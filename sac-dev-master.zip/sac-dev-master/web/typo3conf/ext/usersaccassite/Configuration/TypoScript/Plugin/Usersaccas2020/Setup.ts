<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccas2020/Configuration/TypoScript/setup.ts">

plugin.tx_usersaccas2020_sac2020 {
  settings {
    pid < lib.settings.pid
    pid.sac2020 {
      list = {$PID.sac2020.list}
      detail = {$PID.sac2020.detail}
    }
    path < lib.settings.path
    transparentPixel < lib.settings.transparentPixel
    defaultHeaderType < lib.settings.defaultHeaderType
    pageTitleSeparator = {$site.title.separator}
  }
}
