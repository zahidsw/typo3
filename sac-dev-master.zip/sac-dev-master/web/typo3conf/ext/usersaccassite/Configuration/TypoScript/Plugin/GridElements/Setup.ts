<INCLUDE_TYPOSCRIPT: source="FILE: EXT:gridelements/Configuration/TypoScript/setup.ts">

tt_content.gridelements_pi1.20.10.setup {
  layout1col < lib.gridelements.defaultGridSetup
  layout1col {
    cObject = FLUIDTEMPLATE
    cObject {
      file = Layout1Col.html
      file.wrap = {$PATH.private}Ext/GridElements/Templates/|
      partialRootPaths {
        10 = {$PATH.private}Ext/FluidStyledContent/Partials/
        20 = {$PATH.private}Partials/
      }
      settings < lib.settings
      extbase.controllerExtensionName = Usersaccassite
    }
  }
  layout2col < .layout1col
  layout2col {
    cObject {
      file = Layout2Col.html
    }
  }
  content2col < .layout1col
  content2col {
    cObject {
      file.data = field:flexform_colType
      file.wrap = Content2Col_|.html
    }
  }
  content3col < .layout1col
  content3col {
    cObject.file = Content3Col.html
  }
  content4col < .layout1col
  content4col {
    cObject.file = Content4Col.html
  }

  contentNestedItem < .layout1col
  contentNestedItem {
    cObject.file = ContentNestedItem.html
  }
  layoutAccordions < .layout1col
  layoutAccordions {
    cObject.file = LayoutAccordions.html
  }
  layoutSlideInPanel < .layout1col
  layoutSlideInPanel {
    cObject.file = LayoutSlideInPanel.html
  }
  layoutTabs < .layout1col
  layoutTabs {
    cObject.file = LayoutTabs.html
  }
}
