config {
  ## Language Settings
  linkVars = L(0-3)
  defaultGetVars {
    L = 0
  }
  sys_language_uid = {$site.sys_language_uid}
  sys_language_overlay = hideNonTranslated
  language = {$site.language}
  locale_all = {$site.locale_all}

  sys_language_softMergeIfNotBlank = tt_content:image, tt_content:caption
  sys_language_mode = {$site.sys_language_mode}
  sys_language_isocode_default = de
  sys_language_isocode = {$site.sys_language_isocode}

  uniqueLinkVars = 1
  pageTitleFirst = 1

  spamProtectEmailAddresses = 1

  ## RealURL Settings
  simulateStaticDocuments = 0
  tx_realurl_enable = 1
  absRefPrefix = /
  typolinkEnableLinksAcrossDomains = 1

  debug = {$site.debug}

  admPanel = 1

  index_enable = 1

  removeDefaultJS = external
  compressCss = 1
  concatenateCss = 1
  concatenateJs = 1
  compressJs = 1

  no_cache = 0
  sendCacheHeaders = 1
  cache_period = 86400
  cache_clearAtMidnight = 1

  typolinkLinkAccessRestrictedPages = {$PID.login}
  typolinkLinkAccessRestrictedPages_addParams = &return_url=###RETURN_URL###

  doctype = html5
  htmlTag_stdWrap {
    setContentToCurrent = 1
    cObject = COA
    cObject {
      20 = TEXT
      20 {
        addParams.lang = {$site.language}-{$site.countryCode}
        addParams.dir = ltr
        addParams.prefix = og: http://ogp.me/ns#
        # return at end of line
        append = TEXT
        append.char = 10
        current = 1
      }
      20.addParams.class = no-js ie7 lte-ie9 lte-ie8 lte-ie7 oldie
      20.wrap = <!--[if IE 7]>|<![endif]-->

      30 < .20
      30.addParams.class = no-js ie8 lte-ie9 lte-ie8 oldie
      30.wrap = <!--[if IE 8]>|<![endif]-->

      40 < .20
      40.addParams.class = no-js ie9 lte-ie9
      40.wrap = <!--[if IE 9]>|<![endif]-->

      60 < .20
      60.addParams.class = no-js
      60.wrap = <!--[if gt IE 9]><!-->|<!--<![endif]-->
    }
  }
}
