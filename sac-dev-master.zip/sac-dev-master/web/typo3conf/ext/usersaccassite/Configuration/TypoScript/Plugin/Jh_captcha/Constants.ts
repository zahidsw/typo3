<INCLUDE_TYPOSCRIPT: source="FILE:EXT:jh_captcha/Configuration/TypoScript/constants.txt">
plugin.tx_jhcaptcha {
    settings {
        reCaptcha {
            # cat=plugin.tx_jhcaptcha/recaptcha; type=string; label=Site key: See https://www.google.com/recaptcha/admin
            siteKey = 6Lf5niEUAAAAAKaCBkiSiEpzz4IAPHMz33C5kFOx
            # cat=plugin.tx_jhcaptcha/recaptcha; type=string; label=Secret key: See https://www.google.com/recaptcha/admin
            secretKey = 6Lf5niEUAAAAAIJZOATXWb2Ux0JDSV0hKa64L840
        }
    }
}
