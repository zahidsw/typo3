<INCLUDE_TYPOSCRIPT: source="FILE:EXT:handlebars/Configuration/TypoScript/Setup.ts">

lib.handlebars < plugin.tx_handlebars
lib.handlebars {
  # Root path of handlebars partials
  templatesRootPath = EXT:usersaccassite/Resources/Private/Handlebars/
  partialsRootPath = EXT:usersaccassite/Resources/Private/Handlebars/

  tempPath = typo3temp/var/Cache/Code/handlebars/

  # Default variables (available in all templates)
  variables {
    global {
      svgSprite = /{$PATH.media}svg/svg-sprite.svg
      transparentPixel = data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7
    }
  }
}
