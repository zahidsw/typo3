<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccas2020/Configuration/TypoScript/constants.ts">

plugin.tx_usersaccas2020_sac2020 {
  view {
    templateRootPath = EXT:usersaccassite/Resources/Private/Templates/
    partialRootPath = EXT:usersaccassite/Resources/Private/Partials/
    layoutRootPath = EXT:usersaccassite/Resources/Private/Layouts/
  }
  settings {
    pid {
      sac2020 {
        list =
        detail =
      }
    }
  }
}
