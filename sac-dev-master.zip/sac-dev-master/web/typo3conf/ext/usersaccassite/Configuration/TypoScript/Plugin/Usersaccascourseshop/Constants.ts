<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccascourseshop/Configuration/TypoScript/constants.ts">
