<INCLUDE_TYPOSCRIPT: source="FILE:EXT:static_info_tables/Configuration/TypoScript/Static/setup.txt">

#Extbase config
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:static_info_tables_de/Configuration/TypoScript/Extbase/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:static_info_tables_fr/Configuration/TypoScript/Extbase/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:static_info_tables_it/Configuration/TypoScript/Extbase/setup.txt">
