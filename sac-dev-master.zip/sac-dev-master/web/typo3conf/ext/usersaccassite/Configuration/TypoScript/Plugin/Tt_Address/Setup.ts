config.tx_extbase {
  persistence{
    classes {
      Saccas\Usersaccassite\Domain\Model\Address {
        mapping {
          tableName = tt_address
        }
      }
    }
  }
}
