<INCLUDE_TYPOSCRIPT: source="FILE:EXT:solr/Configuration/TypoScript/Solr/constants.txt">

plugin.tx_solr {
	solr {
		scheme = http
		host = 10.10.100.223
		port = 8983
		path = /solr/core_de/
	}
}

[globalVar = GP:L = 1]
	plugin.tx_solr.solr.path = /solr/core_fr/
[globalVar = GP:L = 2]
	plugin.tx_solr.solr.path = /solr/core_it/
[globalVar = GP:L = 3]
  plugin.tx_solr.solr.path = /solr/core_en/
[end]
