[globalVar = TSFE : beUserLogin > 0] || [globalVar = GP:debug = 1]
  plugin.tx_min.tinysource.enable = 0
  config {
    linkVars := addToList(debug(1))
  }
[else]
  plugin.tx_min.tinysource {
    enable = 1
    head {
      stripTabs = 1
      stripNewLines = 0
      stripDoubleSpaces = 1
      stripTwoLinesToOne = 1
    }
    body {
      stripComments = 1
      stripTabs = 1
      stripNewLines = 0
      stripDoubleSpaces = 1
      stripTwoLinesToOne = 1
      preventStripOfSearchComment = 1
    }
    oneLineMode = 1
  }
[global]
