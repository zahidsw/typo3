page {
  includeCSS {
    main = {$PATH.stylesheets}main{$PATH.productionMinifiedPostfix}.css
    main {
      excludeFromConcatenation = 1
      disableCompression = 1
    }
  }
  includeJS {
    head = {$PATH.scripts}head{$PATH.productionMinifiedPostfix}.js
    head {
      excludeFromConcatenation = 1
      forceOnTop = 1
      disableCompression = 1
    }
    headASync = {$PATH.scripts}head_async{$PATH.productionMinifiedPostfix}.js
    headASync {
      async = 1
      excludeFromConcatenation = 1
      disableCompression = 1
    }
  }
  jsInline {
    10 = TEXT
    10.value (
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','{$site.google.tagManager}');
    )
    20 = COA
    20 {
      50 = COA
      50 {
        20 = TEXT
        20.value = "svgSprite":"/{$PATH.media}svg/svg-sprite.svg",

        30 = TEXT
        30.value = "transparentPixel":"{$site.transparentPixel}",

        40 = TEXT
        40.value = "lang":"{$site.language}",

        50 = COA
        50 {
          10 = TEXT
          10.value = poi:'{$site.api.poi}',

          15 = TEXT
          15.value = poiSearch:'{$site.api.poiSearch}',

          20 = TEXT
          20.value = route:'{$site.api.route}',

          30 = TEXT
          30 {
            typolink {
              parameter = {$PID.rootPage}
              additionalParams = &eID=routing&route=usersaccassite/feuser/current
              returnLast = url
            }
            wrap = loginStatus: '|',
          }

          wrap = api:{|},
        }

        55 = TEXT
        55.value = mapApiUrl:'https://int.suissealpine.sac-cas.ch/build/samap.wrapper.js',
        56 = TEXT
        56.typolink.parameter = {$PID.sac2020.detail}
        56.typolink.returnLast = url
        56.wrap = baseDestinationLinkUrl:'|',
        57 = TEXT
        57.value = route
        57.wrap = destinationLinkRouteAnchor:'|',
        58 = TEXT
        58.value = /index.php?eID=routing&L={$site.sys_language_uid}&route=usersaccas2020/coordinates/convert/lv03towgs84/
        58.wrap = baseJourneyLinkUrl:'|',
        59 = TEXT
        59.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:external.link.sbb.timetable
        59.wrap = basePublicTransportLinkUrl:'|',

        60 = COA
        60 {
          10 = COA
          10 {
            10 = TEXT
            10.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.alpine_tour
            10.wrap = alpine_tour:'|',
            20 = TEXT
            20.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.climbing
            20.wrap = climbing:'|',
            30 = TEXT
            30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.mountain_hiking
            30.wrap = mountain_hiking:'|',
            40 = TEXT
            40.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.ski_tour
            40.wrap = ski_tour:'|',
            50 = TEXT
            50.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.snowshoe_tour
            50.wrap = snowshoe_tour:'|',
            60 = TEXT
            60.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.discipline.via_ferrata
            60.wrap = via_ferrata:'|',

            wrap = disciplines:{|},
          }

          20 = TEXT
          20.data = LLL:EXT:usersaccastranslations/Resources/Private/Language/locallang.xlf:metersOverSeaLevel.short
          20.wrap = altitudeSuffix:'|',
          21 = TEXT
          21.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.heightMeter.short
          21.wrap = altitudeDifferenceUnit:'|',
          22 = TEXT
          22.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.hour.short
          22.wrap = hoursUnit:'|',
          23 = TEXT
          23.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.difficulty
          23.wrap = difficulty:'|',
          24 = TEXT
          24.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.ascent
          24.wrap = ascent:'|',
          25 = TEXT
          25.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.descent
          25.wrap = descent:'|',

          30 = COA
          30 {
            10 = TEXT
            10.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.summit
            10.wrap = summit:'|',
            20 = TEXT
            20.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.hut
            20.wrap = hut:'|',
            30 = TEXT
            30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.traverse
            30.wrap = traverse:'|',
            40 = TEXT
            40.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.marking_point
            40.wrap = marking_point:'|',
            50 = TEXT
            50.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.departure_arrival
            50.wrap = departure_arrival:'|',
            60 = TEXT
            60.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.climbing_area
            60.wrap = climbing_area:'|',

            wrap = destinations:{|},
          }

          40 = COA
          40 {
            10 = TEXT
            10.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.legend
            10.wrap = legend:'|',
            20 = TEXT
            20.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.zoomIn
            20.wrap = zoomIn:'|',
            30 = TEXT
            30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.zoomOut
            30.wrap = zoomOut:'|',
            40 = TEXT
            40.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.enterFullscreenMode
            40.wrap = enterFullscreenMode:'|',
            50 = TEXT
            50.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.leaveFullscreenMode
            50.wrap = leaveFullscreenMode:'|',
            60 = TEXT
            60.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:map.searchLabel
            60.wrap = searchLabel:'|',

              wrap = map:{|},
          }

          50 = COA
          50 {
            10 = TEXT
            10.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.lake
            10.wrap = lake:'|',
            20 = TEXT
            20.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.catering
            20.wrap = catering:'|',
            30 = TEXT
            30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.waterfall
            30.wrap = waterfall:'|',
            40 = TEXT
            40.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.cave
            40.wrap = cave:'|',
            50 = TEXT
            50.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.bridge
            50.wrap = bridge:'|',
            60 = TEXT
            60.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.alp
            60.wrap = alp:'|',
            70 = TEXT
            70.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:common.other
            70.wrap = other:'|',

            wrap = markingPoints:{|},
          }

          60 = COA
          60 {
            10 = TEXT
            10.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.publicTransport
            10.wrap = publicTransport:'|',
            20 = TEXT
            20.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.parkingInformations
            20.wrap = parkingInformations:'|',
            30 = TEXT
            30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.planJourneyPublicTransport
            30.wrap = planJourneyPublicTransport:'|',
            40 = TEXT
            40.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.planJourneyCar
            40.wrap = planJourneyCar:'|',
            50 = TEXT
            50.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.downloadWaypoint
            50.wrap = downloadWaypoint:'|',
            60 = TEXT
            60.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:mapInfoWindow.routeLinkLabel
            60.wrap = routeLinkLabel:'|',

            wrap = mapInfoWindow:{|},
          }

          wrap = translations:{|},
        }

        70 = COA
        70 {
          10 = COA
          10 {
            10 = TEXT
            10.value = [[600],[1200],[2048]],
            10.wrap = sizeList:|

            20 = COA
            20 {
              10 = IMG_RESOURCE
              10 {
                file = {$PATH.public}{$PATH.default.image}{$site.default.image.summit}
                file.width = 600
                stdWrap.wrap = '/|',
              }
              20 < .10
              20.file.width = 1200
              30 < .10
              30.file.width = 2048
              30.stdWrap.wrap = '/|'

              wrap = urlList:[|],
            }

            wrap = summit:{srcset:{|}},
          }

          20 < .10
          20 {
            20 {
              10.file = {$PATH.public}{$PATH.default.image}{$site.default.image.hut}
              20.file < .10.file
              30.file < .10.file
            }
            wrap = hut:{srcset:{|}},
          }

          wrap = destinationFallbackImages:{|},
        }

        wrap = global:{|},
      }
      wrap = estatico.helpers.extend(estatico.data,{|});
    }
  }
  3 = TEXT
  3 {
    value = <iframe src="https://www.googletagmanager.com/ns.html?id={$site.google.tagManager}" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    wrap = <noscript>|</noscript>
  }
  includeJSFooter {
    main = {$PATH.scripts}main{$PATH.productionMinifiedPostfix}.js
    main {
      async = 1
      excludeFromConcatenation = 1
      disableCompression = 1
    }
  }


  # Async jquery loading scripts
  9999999999 = COA
  9999999999 {
    10 = COA
    10 {
      10 = TEXT
      10.value = /typo3conf/ext/powermail_cond/Resources/Public/JavaScript/PowermailCondition.min.js
      10.wrap = jQuery.getScript('|');

      wrap = function addScripts(){|}
    }

    90 = TEXT
    90.value (
      window.onload = function () {
        if (window.jQuery) {
          addScripts();
        } else {
          document.querySelector('script[src^="{$PATH.scripts}main"]').addEventListener('load', addScripts);
        }
      }
    )
    wrap = <script>|</script>
  }
}
