plugin.tx_variables {
    persistence {
        storagePid = {$PID.variables}
    }
}
