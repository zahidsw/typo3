<INCLUDE_TYPOSCRIPT: source="FILE:EXT:cs_seo/Configuration/TypoScript/Setup/lib.currenUrl.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:cs_seo/Configuration/TypoScript/Setup/meta.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:cs_seo/Configuration/TypoScript/Setup/module.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:cs_seo/Configuration/TypoScript/Setup/plugin.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:cs_seo/Configuration/TypoScript/Setup/tracking.ts">

<INCLUDE_TYPOSCRIPT: source="DIR:EXT:cs_seo/Configuration/TypoScript/PageTypes/" extensions="ts">

plugin.tx_csseo {
  sitetitle = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:page.title
  sitemap.pages {
    rootPid = {$PID.rootPage}
    languageUids = {$site.lang.uids}
  }
}

config.pageTitleSeparator = {$site.title.separator}

# remove <link rel="alternate" ... />
page.headerData.654.20 >

# Take care of the rootpage and news detail view

[globalVar = TSFE:id = {$PID.rootPage}] || [globalVar = GP:tx_news_pi1|news > 0]
  config.noPageTitle = 2
  page.headerData.1485350253 = COA
  page.headerData.1485350253 {
    30 = TEXT
    30.data = LLL:EXT:usersaccassite/Resources/Private/Language/locallang.xlf:page.title
    wrap = <title>|</title>
  }
[global]

[globalVar = GP:tx_news_pi1|news > 0]

  # remove canonical on detail view => add in detail.html template
  page.headerData.654.10 >

  page.headerData.1485350253 {
    10 = RECORDS
    10 {
      dontCheckPid = 1
      tables = tx_news_domain_model_news
      source {
        data = GP:tx_news_pi1|news
        intval = 1
      }
      conf {
        tx_news_domain_model_news = TEXT
        tx_news_domain_model_news {
          field = title
          stdWrap.htmlSpecialChars = 1
        }
      }
    }
    20 = TEXT
    20.value = {$site.title.separator}
    20.noTrimWrap = | | |
  }
[global]

[globalVar = GP:tx_usersaccas2020_sac2020|poiId > 0]
  config.noPageTitle = 2

  # remove canonical on tx_usersaccas2020_sac2020 poi detail view => added typo3conf/ext/usersaccas2020/Resources/Private/Templates/Poi/Detail.html
  page.headerData.654.10 >

  # Disable open graph for the tx_usersaccas2020_sac2020
  page.headerData.654.30 >
[global]
