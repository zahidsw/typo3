<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccascourseshop/Configuration/TypoScript/setup.ts">

plugin.tx_usersaccascourseshop_course {
  view {
    layoutRootPaths {
      10 = EXT:usersaccassite/Resources/Private/Ext/Usersaccascourseshop/Layouts/
    }
    templateRootPaths {
      5 = EXT:usersaccassite/Resources/Private/Templates/
      10 = EXT:usersaccassite/Resources/Private/Ext/Usersaccascourseshop/Templates/
    }
    partialRootPaths {
      5 = EXT:usersaccassite/Resources/Private/Partials/
      10 = EXT:usersaccassite/Resources/Private/Ext/Usersaccascourseshop/Partials/
    }
  }

  settings {
    pid < lib.settings.pid
    path < lib.settings.path
    transparentPixel < lib.settings.transparentPixel
    defaultHeaderType < lib.settings.defaultHeaderType
  }

  persistence.storagePid = {$PID.courses}
}

plugin.tx_usersaccascourseshop_basket < plugin.tx_usersaccascourseshop_course
plugin.tx_usersaccascourseshop_checkout < plugin.tx_usersaccascourseshop_course
