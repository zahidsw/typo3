<INCLUDE_TYPOSCRIPT: source="FILE: EXT:news/Configuration/TypoScript/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE: EXT:eventnews/Configuration/TypoScript/setup.txt">

plugin.tx_news {
  view {
    layoutRootPaths {
      2 = EXT:eventnews/Resources/Private/Templates/
      3 = EXT:usersaccassite/Resources/Private/Ext/News/Layouts/
    }
    templateRootPaths {
      2 = EXT:eventnews/Resources/Private/Templates/
      5 = EXT:usersaccassite/Resources/Private/Templates/
      10 = EXT:usersaccassite/Resources/Private/Ext/News/Templates/
    }
    partialRootPaths {
      2 = EXT:eventnews/Resources/Private/Templates/
      3 = EXT:usersaccassite/Resources/Private/Ext/FluidStyledContent/Partials/
      5 = EXT:usersaccassite/Resources/Private/Partials/
      10 = EXT:usersaccassite/Resources/Private/Ext/News/Partials/
    }
  }
  settings {
    pid < lib.settings.pid
    path < lib.settings.path
    transparentPixel < lib.settings.transparentPixel
    defaultHeaderType < lib.settings.defaultHeaderType

    cssFile >
    overrideFlexformSettingsIfEmpty = cropMaxCharacters,dateField,timeRestriction,orderBy,orderDirection,backPid,listPid,startingpoint,recursive,limit,list.paginate.itemsPerPage,list.paginate.templatePath,startingpoint
    detailPid = {$PID.news.detail}
    defaultDetailPid = {$PID.news.detail}
    detailPidDetermination = categories,flexform, default
    startingpoint = {$PID.news.sysFolder}
    facebookLocale = {$site.language}_{$site.countryCode}
    disqusLocale = {$site.language}
    googlePlusLocale = {$site.language}
    opengraph {
      site_name = {$site.title}
      type = article
      email = {$site.email}
      twitter {
        card = summary
        site = {$site.title}
        creator = {$site.meta.author}
      }
    }
    detail {
      errorHandling = redirectToPage,{$PID.rootPage},404
      showSocialShareButtons = 0
    }
    list {
      paginate {
        itemsPerPage = 4
        maximumNumberOfLinks = 3
      }
    }
  }
}

lib.news = USER
lib.news {
  userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
  pluginName = Pi1
  vendorName = GeorgRinger
  extensionName = News
  controller = News
  settings = < plugin.tx_news.settings
  persistence = < plugin.tx_news.persistence
  view = < plugin.tx_news.view
}

lib.news.list < lib.news
lib.news.list {
  action = list
  switchableControllerActions.News.1 = list
}

lib.news.detail < lib.news
lib.news.detail {
  action = detail
  switchableControllerActions.News.1 = detail
}

[globalVar = TSFE:page|categories > 0]

temp.currentPageCats = CONTENT
temp.currentPageCats {
  table = pages
  select {
    uidInList = this
    pidInList = 0
    selectFields = sys_category.uid as catUid
    join = sys_category_record_mm ON pages.uid = sys_category_record_mm.uid_foreign JOIN sys_category ON sys_category.uid = sys_category_record_mm.uid_local
    where = sys_category_record_mm.tablenames = 'pages' AND sys_category_record_mm.uid_foreign = {TSFE:id} AND sys_language_uid = 0
    where.insertData = 1
  }
  renderObj = TEXT
  renderObj {
    field = catUid
    wrap = |,
  }
}

lib.page.stage < lib.news.list
lib.page.stage {
  settings {
    useStdWrap = categories
    categories.override.cObject < temp.currentPageCats
    categoryConjunction = or
    includeSubCategories = 1
    topNewsRestriction = 1
    limit = 6
    templateLayout = stage
  }
}
[ELSE]
# see in the EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccassite/Setup.ts for the override
[global]

[globalVar = GP:tx_news_pi1|news > 0]
  lib.page.newsDetail < lib.news.detail
  lib.page.stage >
[global]

lib.news.perCategory < lib.news.list
lib.news.perCategory {
  settings {
    useStdWrap = categories
    categories.override.cObject = CONTENT
    categories.override.cObject {
      table = sys_category
      select {
        pidInList = {$PID.category.region}
        selectFields = sys_category.uid as catUid
        where.dataWrap = title = '{field: regions_denormalization}'
      }
      renderObj = TEXT
      renderObj {
        field = catUid
        wrap = |,
      }
    }
    categoryConjunction = or
    includeSubCategories = 0
    limit = 3
    templateLayout = relatedNews
  }
}

ajaxNews = PAGE
ajaxNews {
  typeNum = 1485857210
  config {
    disableAllHeaderCode = 1
    xhtml_cleaning = none
    admPanel = 0
    metaCharset = utf-8
    additionalHeaders {
      10.header = Content-Type:text/html;charset=utf-8
    }
    disablePrefixComment = 1
    debug = 0
  }
  10 < lib.news.list
  10 {
    settings{
      overrideFlexformSettingsIfEmpty := addToList(list.ajax.paginate.templatePath)
      useStdWrap = offset
      offset.data = GP:tx_news_pi1|offset
      offset.stdWrap.intval = 1
      categoryConjunction = or
      format = ajax.html
      eventRestriction = 2
      hidePagination = 1
      list.ajax.paginate.itemsPerPage = 6
      list.ajax.paginate.templatePath = EXT:usersaccassite/Resources/Private/Ext/News/Templates/ViewHelpers/Widget/Paginate/Index.ajax.html
    }
  }
}

ajaxEvents < ajaxNews
ajaxEvents {
  typeNum = 1485857211
  10.settings{
    eventRestriction = 1
  }
}

eventIcal < ajaxNews
eventIcal {
  typeNum = 1485857212
  config {
    additionalHeaders {
      10.header = Content-Type:text/calendar;charset=utf-8
    }
  }
  10 < lib.news.detail
  10 {
    settings{
      eventRestriction = 1
      format = ical
      useStdWrap = domain
      domain.data = getEnv:HTTP_HOST
    }
  }
}
