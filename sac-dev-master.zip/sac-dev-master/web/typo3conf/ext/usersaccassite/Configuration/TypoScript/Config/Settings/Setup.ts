lib.settings {
  pid {
    rootPage = {$PID.rootPage}

    menu {
      navPrimary = {$PID.menu.navPrimary}
      navSecondary = {$PID.menu.navSecondary}
      quicklinks = {$PID.menu.quicklinks}
      footer = {$PID.menu.footer}
    }

    news {
      detail = {$PID.news.detail}
    }

    event {
      detail = {$PID.event.detail}
    }

    category {
      activity = {$PID.category.activity}
      main = {$PID.category.main}
      region = {$PID.category.region}
      section = {$PID.category.section}
      tags = {$PID.category.tags}
    }

    mySac = {$PID.mySac}
    search = {$PID.search}

    login = {$PID.login}

    excluded {
      breadcrumb = {$PID.excluded.breadcrumb}
    }
  }

  language = {$site.language}
  countryCode = {$site.countryCode}

  email = {$site.email}

  path.svgSprite = /{$PATH.media}svg/svg-sprite.svg

  defaultHeaderType = {$content.defaultHeaderType}

  transparentPixel = {$site.transparentPixel}
}
