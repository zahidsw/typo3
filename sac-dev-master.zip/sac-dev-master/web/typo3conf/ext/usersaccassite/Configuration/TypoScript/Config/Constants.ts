site {

  baseUrl = https://www.sac-cas.ch/
  domain = www.sac-cas.ch

  debug = 0

  meta {
    author = Schweizer Alpen-Club
    robots = index,follow
  }

  title = Schweizer Alpen Club
  title.separator = |
  logo =

  email = info@sac-cas.ch

  google {
    tagManager =
  }

  transparentPixel = data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7

  api {
    poi = https://int.suissealpine.sac-cas.ch/api/1/sacplus/poi/
    poiSearch = https://int.suissealpine.sac-cas.ch/api/1/poi/search
    route = https://int.suissealpine.sac-cas.ch/api/1/route/
  }

  default {
    image {
      climbing_area = ClimbingArea.jpg
      hut = Hut.jpg
      marking_point = MarkingPoint.jpg
      summit = Summit.jpg
      traverse = Traverse.jpg
    }
  }
}

content.defaultHeaderType = 2

contentObjectExceptionHandler = 1
