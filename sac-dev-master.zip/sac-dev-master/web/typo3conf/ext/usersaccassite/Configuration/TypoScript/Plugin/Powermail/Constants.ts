<INCLUDE_TYPOSCRIPT: source="FILE:EXT:powermail/Configuration/TypoScript/Main/constants.txt">
plugin.tx_powermail {
  settings {
    javascript {
      addJQueryFromGoogle = 0
      addAdditionalJavaScript = 0
    }
    receiver {
      default {
      }
      overwrite {
        senderName = Schweizer Alpen Club SAC
        senderEmail = info@sac-cas.ch
      }
    }
    sender {
      default {
      }
      overwrite {
        senderName = Schweizer Alpen Club SAC
        senderEmail = info@sac-cas.ch
      }
    }
  }
}
