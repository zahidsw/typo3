PID {
  rootPage = 1

  variables = 259

  menu {
    navPrimary = 312
    navSecondary = 223
    quicklinks = 246
    footer = 224
  }

  news {
    sysFolder = 66, 67
    detail = 261
  }
  event {
    detail = 261
  }

  category {
    activity = 352
    main = 354
    region = 353
    section = 356
    tags = 355
  }

  author = 255
  promotions = 253
  sponsors = 243

  mySac = 11
  search = 311

  casmarketing {
    storage = 322
  }

  sac2020 {
    list = 307
    detail = 308
  }

  excluded {
    breadcrumb = 2
  }

  login = 580

  feUsers = 65

  courses = 69
}
