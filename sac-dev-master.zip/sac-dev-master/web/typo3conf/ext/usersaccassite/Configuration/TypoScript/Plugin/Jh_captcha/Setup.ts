<INCLUDE_TYPOSCRIPT: source="FILE:EXT:jh_captcha/Configuration/TypoScript/setup.txt">
