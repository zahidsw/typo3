## Including Configuration
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/ParseFunc/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Settings/Setup.ts">

## Including Page
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Resources/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/BodyTagCObject/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Favicons/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Meta/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Menus/Setup.ts">

## Override / Config Sysext
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/FluidStyledContent/Setup.ts">

## Including Plugin
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Handlebars/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccassite/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Form/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Tt_Address/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/GridElements/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Solr/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Cs_Seo/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Variables/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Min/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/StaticInfoTables/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/News/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Powermail/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Jh_captcha/Setup.ts">

<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Fal_Securedownload/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Oidc/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Casmarketing/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccas2020/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccascourseshop/Setup.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Felogin/Setup.ts">

## Including Page Types
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Page/Type/Setup.ts">
