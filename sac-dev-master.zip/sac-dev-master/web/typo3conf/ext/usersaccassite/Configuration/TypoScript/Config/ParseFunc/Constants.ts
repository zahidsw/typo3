lib.parseFunc.allowTags = figure, figurecaption
