lib.contentElement {
  templateRootPaths.10 = {$PATH.private}Ext/FluidStyledContent/Templates/
  partialRootPaths {
    10 = {$PATH.private}Ext/FluidStyledContent/Partials/
    20 = {$PATH.private}Partials/
  }
  layoutRootPaths.10 = {$PATH.private}Ext/FluidStyledContent/Layouts/
  settings < lib.settings
}

lib.calc = TEXT
lib.calc {
  current = 1
  prioriCalc = 1
}
