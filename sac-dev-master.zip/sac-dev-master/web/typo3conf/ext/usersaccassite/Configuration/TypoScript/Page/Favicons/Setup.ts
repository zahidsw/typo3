page {
	shortcutIcon = {$PATH.public}Icons/favicon.ico

	headerData {
		1464368321 = TEXT
		1464368321 {
			value (
<link rel="apple-touch-icon" sizes="57x57" href="{$PATH.public}Icons/apple-touch-icon-57x57.png"/>
<link rel="apple-touch-icon" sizes="60x60" href="{$PATH.public}Icons/apple-touch-icon-60x60.png"/>
<link rel="apple-touch-icon" sizes="72x72" href="{$PATH.public}Icons/apple-touch-icon-72x72.png"/>
<link rel="apple-touch-icon" sizes="76x76" href="{$PATH.public}Icons/apple-touch-icon-76x76.png"/>
<link rel="apple-touch-icon" sizes="114x114" href="{$PATH.public}Icons/apple-touch-icon-114x114.png"/>
<link rel="apple-touch-icon" sizes="120x120" href="{$PATH.public}Icons/apple-touch-icon-120x120.png"/>
<link rel="apple-touch-icon" sizes="144x144" href="{$PATH.public}Icons/apple-touch-icon-144x144.png"/>
<link rel="apple-touch-icon" sizes="152x152" href="{$PATH.public}Icons/apple-touch-icon-152x152.png"/>
<link rel="apple-touch-icon" sizes="180x180" href="{$PATH.public}Icons/apple-touch-icon-180x180.png"/>
<link rel="icon" type="image/png" href="{$PATH.public}Icons/favicon-32x32.png" sizes="32x32"/>
<link rel="icon" type="image/png" href="{$PATH.public}Icons/android-chrome-192x192.png" sizes="192x192"/>
<link rel="icon" type="image/png" href="{$PATH.public}Icons/favicon-96x96.png" sizes="96x96"/>
<link rel="icon" type="image/png" href="{$PATH.public}Icons/favicon-16x16.png" sizes="16x16"/>
<link rel="manifest" href="{$PATH.public}Icons/manifest.json"/>
<link rel="mask-icon" href="{$PATH.public}Icons/logo.svg" color="#ffffff"/>
<meta name="msapplication-config" content="{$PATH.public}Icons/browserconfig.xml" >
<meta name="msapplication-TileImage" content="{$PATH.public}Icons/mstile-144x144.png"/>
<meta name="msapplication-TileColor" content="#ffffff"/>
<meta name="theme-color" content="#ffffff"/>
			)
		}
	}
}
