<INCLUDE_TYPOSCRIPT: source="FILE:EXT:static_info_tables/Configuration/TypoScript/Static/constants.txt">

plugin.tx_staticinfotables_pi1 {
  currencyCode = CHF
  countryCode = CHE
  countriesAllowed =
  countryZoneCode = BE
  languageCode = DE
}
