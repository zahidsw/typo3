# Default Constants
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Path/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Pid/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/ParseFunc/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Constants.ts">

## Including Plugin
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Solr/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Cs_Seo/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/StaticInfoTables/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Powermail/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Oidc/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Casmarketing/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccas2020/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Usersaccascourseshop/Constants.ts">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Plugin/Jh_captcha/Constants.ts">
# Override with local constants
<INCLUDE_TYPOSCRIPT: source="FILE:Configuration/current/constants.ts">

# Constants that can not be overwritten
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Config/Language/Constants.ts">
