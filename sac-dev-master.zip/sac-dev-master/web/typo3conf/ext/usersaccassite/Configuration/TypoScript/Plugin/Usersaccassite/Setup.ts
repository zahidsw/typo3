plugin.tx_usersaccassite {

  persistence {
    classes {
      Saccas\Usersaccassite\Domain\Model\FrontendUser {
        mapping {
          tableName = fe_users
        }
      }
    }
  }

  features.requireCHashArgumentForActionArguments = 0

  view {
    layoutRootPaths {
      20 = {$PATH.private}Layouts/
    }
    partialRootPaths {
      20 = {$PATH.private}Partials/
    }
    templateRootPaths {
      20 = {$PATH.private}Templates/
    }
  }
  extbase.controllerExtensionName = Usersaccassite
}

tt_content.usersaccassite_default < lib.contentElement
tt_content.usersaccassite_default {
  layoutRootPaths {
    20 = {$PATH.private}Layouts/
  }
  templateRootPaths {
    20 = {$PATH.private}Templates/Content/
  }
  extbase.controllerExtensionName = Usersaccassite
  settings < lib.settings
}

lib.handlebarsContent = USER
lib.handlebarsContent {
  userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
  vendorName = Saccas
  pluginName = Pi1
  extensionName = Usersaccassite
  controller = CTypeSwitch
  switchableControllerActions {
    CTypeSwitch {
      1 = show
    }
  }

  settings < lib.settings
  settings.handlebars < lib.handlebars
}

tt_content {
  usersaccassite_feuser < lib.handlebarsContent

  usersaccassite_feuserupdateform < tt_content.usersaccassite_default
  usersaccassite_feuserupdateform {
    templateName = Feuserupdateform
  }

  usersaccassite_infobox < lib.handlebarsContent

  usersaccassite_media < tt_content.usersaccassite_default
  usersaccassite_media {
    templateName = Media
    dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
    dataProcessing.10 {
      if.isTrue.field = media
      references {
        fieldName = media
        table = tt_content
      }
      as = medias
    }
  }

  usersaccassite_menu_pills < tt_content.usersaccassite_default
  usersaccassite_menu_pills {
    templateName = MenuPills
    dataProcessing < tt_content.menu_subpages.dataProcessing
    stdWrap < tt_content.menu_subpages.stdWrap
  }
  usersaccassite_menu_pills_pages < tt_content.usersaccassite_default
  usersaccassite_menu_pills_pages {
    templateName = MenuPills
    dataProcessing < tt_content.menu_pages.dataProcessing
    stdWrap < tt_content.menu_pages.stdWrap
  }
  usersaccassite_menu_tabs < tt_content.usersaccassite_menu_pills
  usersaccassite_menu_tabs {
    templateName = MenuTabs
  }
  usersaccassite_menu_tabs_pages < tt_content.usersaccassite_menu_pills_pages
  usersaccassite_menu_tabs_pages {
    templateName = MenuTabs
  }
  usersaccassite_menu_teaser_content_records < tt_content.usersaccassite_default
  usersaccassite_menu_teaser_content_records {
    templateName = MenuTeaserContentRecords
    dataProcessing {
      10 = Saccas\Usersaccassite\DataProcessing\MenuTeaserContentRecordsProcessor
    }
  }
  usersaccassite_menu_teaser_related_records < tt_content.usersaccassite_default
  usersaccassite_menu_teaser_related_records {
    templateName = MenuTeaserRelatedRecords
    dataProcessing {
      10 = Saccas\Usersaccassite\DataProcessing\MenuTeaserRelatedRecordsProcessor
    }
  }

  usersaccassite_messagebox < lib.handlebarsContent

  usersaccassite_sidebar_text_box < lib.handlebarsContent

  usersaccassite_sponsor < tt_content.usersaccassite_default
  usersaccassite_sponsor {
    templateName = Sponsor
    dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
    dataProcessing.10 {
      if.isTrue.field = tx_usersaccassite_sponsor
      table = tx_usersaccassite_domain_model_sponsor
      pidInList = {$PID.sponsors}
      uidInList.field = tx_usersaccassite_sponsor
      as = sponsors
      dataProcessing {
        10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
        10 {
          references.fieldName = image
          as = image
        }
      }
    }
  }

  usersaccassite_vcard < lib.handlebarsContent
}
lib.page {
  header {
    promotion < tt_content.usersaccassite_default
    promotion {
      templateName = Promotion
      dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
      dataProcessing.10 {
        table = tx_usersaccassite_domain_model_promotion
        pidInList = {$PID.promotions}
        max = 1
        as = promotion
      }
    }
  }
  login = USER
  login {
    userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
    vendorName = Saccas
    pluginName = Pi1
    extensionName = Usersaccassite
    controller = Login
    switchableControllerActions {
      Login {
        1 = show
      }
    }
    settings < lib.settings
    settings.handlebars < lib.handlebars
    settings {
      postLoginUrl = {$PID.mySac}
      resetPasswordLinkOrPid = https://haveibeenpwned.com/
      registrationLinkOrPid = {$PID.mySac}
      registrationLinkMembershipOrPid = {$PID.mySac}
    }
  }
  menu {
    main < tt_content.usersaccassite_default
    main {
      templateName = MainMenu
      dataProcessing {
        10 = TYPO3\CMS\Frontend\DataProcessing\MenuProcessor
        10 {
          special = list
          special.value.field = pages
          levels = 4
          as = menu
          expandAll = 1
          includeSpacer = 0
          titleField = nav_title // title
        }
      }
    }
    navPrimary < tt_content.usersaccassite_default
    navPrimary {
      templateName = NavPrimary
      dataProcessing {
        10 = TYPO3\CMS\Frontend\DataProcessing\MenuProcessor
        10 {
          special = directory
          special.value = {$PID.menu.navPrimary}
          levels = 1
          as = menu
          includeSpacer = 0
          titleField = nav_title // title
        }
      }
    }
    navSecondary < .navPrimary
    navSecondary {
      templateName = NavSecondary
      dataProcessing {
        10 {
          special.value = {$PID.menu.navSecondary}
        }
      }
    }
  }
  sidebar {
    author < tt_content.usersaccassite_default
    author {
      templateName = Author
      dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
      dataProcessing.10 {
        if.isTrue.data = page : author_ttaddress
        table = tt_address
        uidInList.data = page : author_ttaddress
        pidInList = {$PID.author}
        max = 4
        dataProcessing {
          10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
          10 {
            references.fieldName = image
          }
        }
        as = authorTtaddress
      }
    }
  }
  footer {
    sponsors < tt_content.usersaccassite_default
    sponsors {
      templateName = SponsorFooter
      dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
      dataProcessing.10 {
        table = tx_usersaccassite_domain_model_sponsor
        if.isTrue.data = field:title
        pidInList = {$PID.sponsors}
        uidInList.cObject = TEXT
        uidInList.cObject {
          data = levelfield : -1 , tx_usersaccassite_sponsor , slide
        }
        as = sponsors
        dataProcessing {
          10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
          10 {
            references.fieldName = image
            as = image
          }
        }
      }
    }
  }
}

lib.page.stage < tt_content.usersaccassite_default
lib.page.stage {
  templateName = StageImage
  dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
  dataProcessing.10 {
    table = pages
    pidInList = 0
    uidInList = this
    max = 1
    as = medias
    dataProcessing {
      10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
      10 {
        references.fieldName = media
      }
    }
  }
}

lib.page.news.campaign < tt_content.usersaccassite_default
lib.page.news.campaign {
  templateName = Campaign
  dataProcessing.10 = TYPO3\CMS\Frontend\DataProcessing\DatabaseQueryProcessor
  dataProcessing.10 {
    table = tx_usersaccassite_domain_model_campaign
    pidInList = 0
    uidInList.current = 1
    max = 1
    as = campaign
    dataProcessing {
      10 = TYPO3\CMS\Frontend\DataProcessing\FilesProcessor
      10 {
        references.fieldName = image
      }
    }
  }
}
