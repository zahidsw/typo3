<INCLUDE_TYPOSCRIPT: source="FILE:EXT:oidc/Configuration/TypoScript/felogin/constants.txt">
