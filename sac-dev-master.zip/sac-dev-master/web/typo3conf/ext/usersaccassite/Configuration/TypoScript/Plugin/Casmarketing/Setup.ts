<INCLUDE_TYPOSCRIPT: source="FILE:EXT:casmarketing/Configuration/TypoScript/setup.ts">

plugin.tx_casmarketing_txcasmarketing {
    view {
        layoutRootPaths {
            50 = EXT:usersaccassite/Resources/Private/Layouts/
        }
        templateRootPaths {
            50 = EXT:usersaccassite/Resources/Private/Templates/
        }
        partialRootPaths {
            50 = EXT:usersaccassite/Resources/Private/Partials/
        }
    }

    persistence {
        storagePid = {$PID.casmarketing.storage}
    }
}