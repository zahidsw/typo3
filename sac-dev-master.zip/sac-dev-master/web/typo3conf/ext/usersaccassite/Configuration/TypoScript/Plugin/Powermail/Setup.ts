<INCLUDE_TYPOSCRIPT: source="FILE:EXT:powermail/Configuration/TypoScript/Main/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:powermail/Configuration/TypoScript/Powermail_Frontend/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:powermail/Configuration/TypoScript/Marketing/setup.txt">

plugin.tx_powermail {
  view {
    templateRootPaths {
      0 = EXT:powermail/Resources/Private/Templates/
      10 = EXT:usersaccassite/Resources/Private/Templates/
      20 = EXT:usersaccassite/Resources/Private/Ext/Powermail/Templates/
    }
    partialRootPaths {
      0 = EXT:powermail/Resources/Private/Partials/
      6 = EXT:jh_captcha/Resources/Private/Powermail/Partials/Jhcaptcharecaptcha/
      10 = EXT:usersaccassite/Resources/Private/Partials/
      20 = EXT:usersaccassite/Resources/Private/Ext/Powermail/Partials/
    }
    layoutRootPaths {
      0 = EXT:powermail/Resources/Private/Layouts/
      10 = EXT:usersaccassite/Resources/Private/Layouts/
      20 = EXT:usersaccassite/Resources/Private/Ext/Powermail/Layouts/
    }
  }
  settings.setup {
    pid < lib.settings.pid
    path < lib.settings.path
    transparentPixel < lib.settings.transparentPixel
    defaultHeaderType < lib.settings.defaultHeaderType
  }
}

page {
  # Constant is not working
  includeJSFooterlibs.powermailJQuery >
  includeJSFooter.powermailMarketing >

# powermailCondition TS BEGIN
  # Included in /web/typo3conf/ext/usersaccassite/Configuration/TypoScript/Page/Resources/Setup.ts
  # includeJSFooter.powermailCond = EXT:powermail_cond/Resources/Public/JavaScript/PowermailCondition.js

  3132 = COA
  3132 {
    wrap = <script id="powermail_conditions_container"|></script>

    # Uri to send AJAX request
    10 = TEXT
    10 {
      noTrimWrap = | data-condition-uri="|"|
        typolink {
        parameter.data = TSFE:id
        additionalParams = &type=3132
        returnLast = url
        forceAbsoluteUrl = 1
      }
    }
  }
}

powermailCondition = PAGE
powermailCondition {
  typeNum = 3132
  config {
    disableAllHeaderCode = 1
    xhtml_cleaning = 0
    admPanel = 0
    metaCharset = UTF-8
    additionalHeaders = Content-type: application/json
    no_cache = 1
    debug = 0
  }

  10 = USER
  10 {
    userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
    extensionName = PowermailCond
    vendorName = In2code
    controller = Condition
    pluginName = Pi1
  }
}
# powermailCondition TS END
