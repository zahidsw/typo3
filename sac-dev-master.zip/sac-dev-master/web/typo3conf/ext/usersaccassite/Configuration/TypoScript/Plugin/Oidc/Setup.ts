<INCLUDE_TYPOSCRIPT: source="FILE:EXT:oidc/Configuration/TypoScript/felogin/setup.txt">
<INCLUDE_TYPOSCRIPT: source="FILE:EXT:oidc/Configuration/TypoScript/setup.txt">

# format is "TYPO3 column" = <OIDC field>
plugin.tx_oidc.mapping {
    fe_users {
        tx_usersaccassite_contact_number = <contact_number>
        username   = <contact_number>
        tx_usersaccassite_gender = <anredecode>
        name       = <name>
        first_name = <vorname>
        last_name  = <familienname>
        address    = <strasse>
        tx_usersaccassite_address2 = <addresszusatz>
        tx_usersaccassite_pobox = <postfach>
        zip        = <plz>
        city       = <ort>
        tx_usersaccassite_state = <kanton>
        country    = <land>
        telephone  = <telefonp>
        tx_usersaccassite_phone_mobile = <telefonmobil>
        tx_usersaccassite_phone_company = <telefong>
        email      = <email>
        tx_usersaccassite_profile_url = <profileurl>
    }
}

plugin.tx_felogin_pi1.storagePid = {$PID.feUsers}
