page.meta {
	# Add meta tag for mobile view
	viewport = width=device-width, initial-scale=1

	X-UA-Compatible = IE=edge
	X-UA-Compatible.attribute = http-equiv

	robots = {$site.meta.robots}

	# Mobile broser color
	theme-color = #213857
	msapplication-navbutton-color = #213857
	apple-mobile-web-app-capable = yes
	apple-mobile-web-app-status-bar-style = black-translucent
}