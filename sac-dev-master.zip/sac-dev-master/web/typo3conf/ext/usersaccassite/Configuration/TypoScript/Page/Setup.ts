page = PAGE
page {
  typeNum = 0

  10 = FLUIDTEMPLATE
  10 {
    variables {
      belayout = TEXT
      belayout.data = levelfield:-1,backend_layout_next_level,slide
      belayout.override.field = backend_layout

      topContent < styles.content.get
      topContent.select.where = colPos=1

      mainContent < styles.content.get

      rightContent < styles.content.get
      rightContent.select.where = colPos=2

      bottomContent < styles.content.get
      bottomContent.select.where = colPos=3

      //right.slide = -1
      /*
      right.stdWrap {
          required = 1
          ifEmpty.cObject < lib.page.sidebar.top
      }
      */
    }

    settings < lib.settings

    extbase.controllerExtensionName = Usersaccassite
    templateRootPaths.10 = {$PATH.private}Templates/
    partialRootPaths.10 = {$PATH.private}Partials/
    layoutRootPaths.10 = {$PATH.private}Layouts/

    # BE layouts
    file.stdWrap.cObject = CASE
    file.stdWrap.cObject {
      key.data = levelfield:-1,backend_layout_next_level,slide
      key.override.field = backend_layout
      default = TEXT
      default.value = {$PATH.private}Templates/Page/Page.html
      pagets__page < .default
      pagets__account = TEXT
      pagets__account.value = {$PATH.private}Templates/Page/Account.html
      pagets__pageDetail = TEXT
      pagets__pageDetail.value = {$PATH.private}Templates/Page/PageDetail.html
      pagets__pageRightColumn = TEXT
      pagets__pageRightColumn.value = {$PATH.private}Templates/Page/PageRightColumn.html
      pagets__pageRoute = TEXT
      pagets__pageRoute.value = {$PATH.private}Templates/Page/PageRoute.html
    }
  }
}

page.config.contentObjectExceptionHandler = {$contentObjectExceptionHandler}
