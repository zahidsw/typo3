plugin.tx_powermail {
  view {
    partialRootPaths.rh_recaptcha = EXT:rh_recaptcha/Resources/Private/Partials/
  }

  settings {
    setup {
      reCAPTCHA {
        siteKey = 6Lf5niEUAAAAAKaCBkiSiEpzz4IAPHMz33C5kFOx
        secretKey = 6Lf5niEUAAAAAIJZOATXWb2Ux0JDSV0hKa64L840
        lang = {$site.sys_language_isocode}
      }
    }
  }
}
