lib {
  parseFunc {
    allowTags := addToList({$lib.parseFunc.allowTags})
  }
}
