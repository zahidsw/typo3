site {
  lang {
    uids = 0, 1, 2, 3
    labels = De || Fr || It || En
    titleLabels = Deutsch || Français || Italian || English
  }
  sys_language_uid = 0
  sys_language_isocode = de
  sys_language_mode = strict
  language = de
  countryCode = CH
  locale_all = de_CH.UTF-8, de_DE.UTF-8
}
plugin.tx_staticinfotables_pi1.languageCode = DE

## Condition to change language settings for French
[globalVar = GP:L = 1]
site {
  sys_language_uid = 1
  sys_language_isocode = fr
  language = fr
  countryCode = CH
  locale_all= fr_CH.UTF-8, fr_DE.UTF-8
}
plugin.tx_staticinfotables_pi1.languageCode = FR
[end]

## Condition to change language settings for Italian
[globalVar = GP:L = 2]
site {
  sys_language_uid = 2
  sys_language_isocode = it
  language = it
  countryCode = CH
  locale_all= it_CH.UTF-8, it_IT.UTF-8
}
plugin.tx_staticinfotables_pi1.languageCode = IT
[end]

## Condition to change language settings for English
[globalVar = GP:L = 3]
site {
  sys_language_uid = 3
  sys_language_isocode = en
  language = en
  countryCode = CH
  locale_all= en_GB.UTF-8, en_US.UTF-8
}
plugin.tx_staticinfotables_pi1.languageCode = EN
[end]

