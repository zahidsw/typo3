plugin.tx_felogin_pi1 {
  redirectMode = getpost
}
