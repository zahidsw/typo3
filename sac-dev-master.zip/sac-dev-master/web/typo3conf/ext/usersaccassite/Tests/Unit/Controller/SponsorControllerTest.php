<?php
namespace Saccas\Usersaccassite\Tests\Unit\Controller;

/**
 * Test case.
 */
class SponsorControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Saccas\Usersaccassite\Controller\SponsorController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Saccas\Usersaccassite\Controller\SponsorController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllSponsorsFromRepositoryAndAssignsThemToView()
    {
        $allSponsors = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $sponsorRepository = $this->getMockBuilder(\Saccas\Usersaccassite\Domain\Repository\SponsorRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $sponsorRepository->expects(self::once())->method('findAll')->will(self::returnValue($allSponsors));
        $this->inject($this->subject, 'sponsorRepository', $sponsorRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('sponsors', $allSponsors);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }
}
