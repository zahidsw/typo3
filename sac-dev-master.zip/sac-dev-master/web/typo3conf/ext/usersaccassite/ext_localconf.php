<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

if (!function_exists('addPageTSConfigForCustomCType')) {
    function addPageTSConfigForCustomCType($module, $icon = 'content-textpic')
    {
        $module = 'usersaccassite_' . strtolower($module);

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('
        mod.wizards.newContentElement.wizardItems.common {
            elements {
                ' . $module . ' {
                    iconIdentifier = ' . $icon . '
                    title = LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db_new_content_el.xlf:wizards.newContentElement.' . $module . '_title
                    description = LLL:EXT:usersaccassite/Resources/Private/Language/locallang_db_new_content_el.xlf:wizards.newContentElement.' . $module . '_description
                    tt_content_defValues {
                        CType = ' . $module . '
                    }
                }
            }
            show := addToList(' . $module . ')
        }');
    }
}

$boot = function () {

    // Register for hook to show preview of tt_content element of CType="yourextensionkey_newcontentelement" in page module
    $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['cms/layout/class.tx_cms_layout.php']['tt_content_drawItem'][] = \Saccas\Usersaccassite\Hooks\PageLayoutView\CustomCTypePreviewRenderer::class;

    addPageTSConfigForCustomCType('feuser');
    addPageTSConfigForCustomCType('infobox');
    addPageTSConfigForCustomCType('media', 'content-textmedia');
    addPageTSConfigForCustomCType('menu_pills');
    addPageTSConfigForCustomCType('menu_pills_pages');
    addPageTSConfigForCustomCType('menu_tabs');
    addPageTSConfigForCustomCType('menu_tabs_pages');
    addPageTSConfigForCustomCType('menu_teaser_content_records');
    addPageTSConfigForCustomCType('menu_teaser_related_records');
    addPageTSConfigForCustomCType('messagebox');
    addPageTSConfigForCustomCType('sidebar_text_box');
    addPageTSConfigForCustomCType('sponsor');
    addPageTSConfigForCustomCType('vcard');

    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
        'Saccas.Usersaccassite',
        'Pi1',
        [
            'CTypeSwitch' => 'show',
            'Login' => 'show',
        ],
        [
            'CTypeSwitch' => '',
            'Login' => '',
        ]
    );

    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
        'Saccas.Usersaccassite',
        'Address',
        [
            'Address' => 'list',
        ],
        [
        ]
    );

    $GLOBALS['TYPO3_CONF_VARS']['EXT']['news']['classes']['Domain/Model/News'][] = 'usersaccassite';

    // Register hook in the core
    $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS'][\TYPO3\CMS\Core\Configuration\FlexForm\FlexFormTools::class]['flexParsing'][] = \Saccas\Usersaccassite\Hooks\FlexFormHook::class;

    /**
     * Register typeConverters for fileUploading or Image Uploading
     */
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerTypeConverter('Saccas\\Usersaccassite\\Property\\TypeConverter\\UploadedFileReferenceConverter');
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerTypeConverter('Saccas\\Usersaccassite\\Property\\TypeConverter\\ObjectStorageConverter');

    /**
     * Register RTE preset config to use with CKEditor
     */
    $GLOBALS['TYPO3_CONF_VARS']['RTE']['Presets']['saccas'] = 'EXT:usersaccassite/Configuration/Yaml/RTE/Saccas.yaml';

    /**
     * Ext:Form hooks
     */
    $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['ext/form']['initializeFormElement'][1504684998] = \Saccas\Usersaccassite\Hooks\Form\FormHook::class;
//    $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['ext/form']['afterInitializeCurrentPage'][1504684998] = \Saccas\Usersaccassite\Hooks\Form\FormHook::class;

    /**
     * Register handlebar helpers
     */
    \JFB\Handlebars\HelperRegistry::getInstance()->register(
        'ifEqual',
        function () {
            $arguments = func_get_args();
            $context = array_pop($arguments);
            return count(array_unique($arguments)) === 1 ? $context['fn']() : ($context['inverse'] ? $context['inverse']() : '');
        }
    );
    \JFB\Handlebars\HelperRegistry::getInstance()->register(
        'ifAny',
        function () {
            $arguments = func_get_args();
            $context = array_pop($arguments);
            $notEmptyArguments = array_filter($arguments);
            return (count($notEmptyArguments) > 0) ? $context['fn']() : ($context['inverse'] ? $context['inverse']() : '');
        }
    );
};

$boot();
unset($boot);
