<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function ($extKey) {
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Saccas.Usersaccassite',
            'Pi1',
            'Extension Usersaccassite'
        );
    },
    $_EXTKEY
);

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    $_EXTKEY,
    'Address',
    'Address - List of addresses'
);

// Register the FlexForms
$TCA['tt_content']['types']['list']['subtypes_excludelist'][$_EXTKEY . '_address'] = 'layout,select_key,pages,recursive';
$TCA['tt_content']['types']['list']['subtypes_addlist'][$_EXTKEY . '_address'] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    $_EXTKEY . '_address',
    'FILE:EXT:' . $_EXTKEY . '/Configuration/FlexForm/Address.xml'
);
