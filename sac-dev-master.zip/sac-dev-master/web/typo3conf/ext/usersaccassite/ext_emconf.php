<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "usersaccassite".
 *
 * Auto generated 12-07-2016 11:28
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = [
    'title' => 'User Sac Cas site',
    'description' => 'User Sac Cas site',
    'category' => 'misc',
    'shy' => 0,
    'version' => '0.0.1',
    'dependencies' => 'extbase,fluid',
    'conflicts' => '',
    'priority' => '',
    'loadOrder' => '',
    'module' => '',
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'modify_tables' => '',
    'clearCacheOnLoad' => 1,
    'lockType' => '',
    'author' => 'Daniel Huf',
    'author_email' => 'daniel.huf@swisscom.com',
    'author_company' => '',
    'CGLcompliance' => '',
    'CGLcompliance_note' => '',
    'constraints' => [
        'depends' => [
            'typo3' => '7.0.0-8.7.99',
            'extbase' => '',
            'fluid' => '',
            'handlebars' => '',
        ],
        'conflicts' => [
        ],
        'suggests' => [
        ],
    ],
    '_md5_values_when_last_written' => 'a:0:{}',
    'suggests' => [
    ],
];
