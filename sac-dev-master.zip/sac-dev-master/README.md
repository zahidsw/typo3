### SAC - CAS

**TYPO3 Setup:**

* Clone the repo `git clone git@github.com:saccas/sac-dev.git sac`
* Create the symlink to the used instance in the /Configuration folder
  * `ln -snf Development/local current`
* run composer 
  * `composer install` for the live configuration
  * `composer install --no-dev` for the dev setup
  * `composer install --no-dev --ignore-platform-reqs` for the dev setup but using php7.1 for example

**TYPO3 Extension Setup:**

* In the main Template load the TS files
  * CONSTANTS 
    * `<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Constants.ts">`
  * SETUP
    * `<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TypoScript/Setup.ts">`
    * On DEV only: `<INCLUDE_TYPOSCRIPT: source="FILE:Configuration/Development/###YOUR_DEV_FOLDER###/setupOverride.ts">`
* In the main page add the PageTSConfig
  * `<INCLUDE_TYPOSCRIPT: source="FILE:EXT:usersaccassite/Configuration/TsConfig/PageTSConfig/Root.ts">`
  
**TYPO3 BE Configuration**
* Select the home and page templates

**Development**

***GIT pre-commit***
* I used this script but without the SASS, CSS and JS to check the PHP for PSR-2. https://github.com/WouterSioen/pre-commit
