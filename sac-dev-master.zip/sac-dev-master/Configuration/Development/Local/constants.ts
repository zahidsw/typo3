site {
    baseUrl = http://sac.dev/
    domain = sac.dev
    meta.robots = noindex, nofollow
    debug = 1
    environment = development-local
}

PID {

}

PATH {
    productionMinifiedPostfix =
    stylesheets = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/css/
    scripts = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/js/
    media = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/media/
}

contentObjectExceptionHandler = 0
