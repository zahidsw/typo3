<?php
$TYPO3_CONF_VARS['EXTCONF']['realurl']['sac.dev'] = $TYPO3_CONF_VARS['EXTCONF']['realurl']['sac-cas.ch'];
$TYPO3_CONF_VARS['EXTCONF']['realurl']['sac.dev']['init']['disableErrorLog'] = 0;
