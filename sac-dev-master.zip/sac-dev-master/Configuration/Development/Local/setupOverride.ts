page {
  includeCSS {
    dev = {$PATH.stylesheets}dev.css
    dev.media = all
  }
  includeJS {
    dev = {$PATH.scripts}dev.js
  }
}
