<?php

// General
$GLOBALS['TYPO3_CONF_VARS']['BE']['installToolPassword'] = '$P$C7JB5UcX4LvIuTP9d1IhnBXHZt.hgA1'; // Equals to '123456789'

$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['charset'] = 'utf8';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['dbname'] = 'sac';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['driver'] = 'mysqli';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['host'] = '127.0.0.1';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['password'] = '';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['port'] = 3306;
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['user'] = 'root';

// Mail setting for mailhog (accessible with http://hostname:8025 on local docker)
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport'] = 'smtp';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_sendmail_command'] = '/usr/sbin/sendmail -t -i';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_encrypt'] = ''; // 'ssl' is recommended on Production
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_password'] = ''; // smtp user password on Production
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_server'] = '0.0.0.0:1025'; // smtp host:port on Production, e.g: smtp.gmail.com:465
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_username'] = ''; // smtp username on Production

$GLOBALS['TYPO3_CONF_VARS']['SYS']['trustedHostsPattern'] = '.*\.dev'; // if on different port than 80, add :port_number after *

// Context specific (default to Development)
$GLOBALS['TYPO3_CONF_VARS']['BE']['debug'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['FE']['debug'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['clearCacheSystem'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['devIPmask'] = '*'; // empty string on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['displayErrors'] = 1; // 0 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['enableDeprecationLog'] = 'file'; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['exceptionalErrors'] = 28674; // 20480 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['sqlDebug'] = 1; // 0 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['systemLogLevel'] = 0; // 2 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['fluid_template']['options']['defaultLifetime'] = 86400;

$GLOBALS['TYPO3_CONF_VARS']['GFX']['processor_path'] = '/usr/local/bin/';
$GLOBALS['TYPO3_CONF_VARS']['GFX']['processor_path_lzw'] = '/usr/local/bin/';
