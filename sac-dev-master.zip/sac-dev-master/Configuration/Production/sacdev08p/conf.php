<?php
// General
$GLOBALS['TYPO3_CONF_VARS']['BE']['installToolPassword'] = '$P$CD/V/V03DEz8QUX17ZJVkDrCuHL0LS1'; // Equals to 'sacdev01p'
$GLOBALS['TYPO3_CONF_VARS']['BE']['lockSSL'] = '2'; // Backend allways over https
$GLOBALS['TYPO3_CONF_VARS']['BE']['compressionLevel'] = 5;

// DB Connection
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['host'] = '10.10.101.94';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['port'] = 3306;
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['charset'] = 'utf8';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['dbname'] = 'sacdev08pm';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['user'] = 'sacdev08p';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['password'] = 'MFiKD$CVRo<e2iyN';
$GLOBALS['TYPO3_CONF_VARS']['DB']['Connections']['Default']['driver'] = 'mysqli';

// Mail setting for mailhog (accessible with http://hostname:8025 on local docker)
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport'] = 'smtp';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_encrypt'] = ''; // 'ssl' is recommended on Production
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_password'] = ''; // smtp user password on Production
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_server'] = '10.10.100.150:1025'; // smtp host:port on Production, e.g: smtp.gmail.com:465
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['transport_smtp_username'] = ''; // smtp username on Production
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromAddress'] = 'dev@sac-cas.ch';
$GLOBALS['TYPO3_CONF_VARS']['MAIL']['defaultMailFromName'] = 'DEV Schweizer Alpen-Club SAC';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['trustedHostsPattern'] = '(.*\.)?(web.sac-cas)\.ch(:(80|443))?'; // if on different port than 80, add :port_number after *
$GLOBALS['TYPO3_CONF_VARS']['SYS']['dbClientCompress'] = 1;
$GLOBALS['TYPO3_CONF_VARS']['SYS']['cookieSecure'] = 1;

// nginx reverse proxy config
// $GLOBALS['TYPO3_CONF_VARS']['SYS']['reverseProxySSL'] = *;
$GLOBALS['TYPO3_CONF_VARS']['SYS']['reverseProxyIP'] = '10.10.100.175';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['reverseProxyHeaderMultiValue'] = 'last';

// Context specific (default to Development)
$GLOBALS['TYPO3_CONF_VARS']['BE']['debug'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['FE']['debug'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['clearCacheSystem'] = true; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['devIPmask'] = '*'; // empty string on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['displayErrors'] = 1; // 0 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['enableDeprecationLog'] = 'file'; // false on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['exceptionalErrors'] = 28674; // 20480 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['sqlDebug'] = 1; // 0 on Production
$GLOBALS['TYPO3_CONF_VARS']['SYS']['systemLogLevel'] = 0; // 2 on Production
$GLOBALS['TYPO3_CONF_VARS']['GFX']['im_path'] = '/usr/bin/';
$GLOBALS['TYPO3_CONF_VARS']['GFX']['im_path_lzw'] = '/usr/bin/';
$GLOBALS['TYPO3_CONF_VARS']['GFX']['im_version_5'] = 'im6';


// FLUID Cache
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['fluid_template']['options']['defaultLifetime'] = 31536000;

// REDIS Caching
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_hash']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_hash']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 15,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_pages']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_pages']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 16,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_pagesection']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_pagesection']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 17,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_rootline']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_rootline']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 18,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['extbase_object']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['extbase_object']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 19,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['extbase_reflection']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['extbase_reflection']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 20,
   'defaultLifetime' => 86400,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
// usersaccas2020 redis
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_usersaccas2020']['backend'] = 'TYPO3\\CMS\\Core\\Cache\\Backend\\RedisBackend';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['caching']['cacheConfigurations']['cache_usersaccas2020']['options'] = [
   'hostname' => '10.10.100.145',
   'database' => 21,
   'defaultLifetime' => 3600,
   'password' => 'ZKJZ6TTYvh]3bä@A',
];
