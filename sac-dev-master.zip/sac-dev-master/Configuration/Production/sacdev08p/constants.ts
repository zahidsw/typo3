site {
    baseUrl = https://devn.web.sac-cas.ch/
    domain = devn8.web.sac-cas.ch
    meta.robots = noindex, nofollow
    debug = 1
    environment = development-sacdev08p

  google {
		// none yet
    // tagManager = GTM-KBPCNN3
  }
}

PID {

}

# Only for dev
contentObjectExceptionHandler = 0
