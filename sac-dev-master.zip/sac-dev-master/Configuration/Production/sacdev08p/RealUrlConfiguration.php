<?php
$TYPO3_CONF_VARS['EXTCONF']['realurl']['devn.web.sac-cas.ch'] = $TYPO3_CONF_VARS['EXTCONF']['realurl']['sac-cas.ch'];
