site {
    baseUrl = https://sacdev01p-zahid.ch.trendhosting.cloud/
    domain = sacdev01p-zahid.ch.trendhosting.cloud
    meta.robots = noindex, nofollow
    debug = 1
    environment = development-sacdev01p-zahid

  google {
		//tagManager = GTM-KBPCNN3
  }
}

PID {

}

PATH {
  productionMinifiedPostfix =
  stylesheets = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/css/
  scripts = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/js/
  media = typo3conf/ext/usersaccassite/Resources/Public/frontend/dev/assets/media/
}
