<?php
$TYPO3_CONF_VARS['EXTCONF']['realurl']['sacdev01p-zahid.ch.trendhosting.cloud'] = $TYPO3_CONF_VARS['EXTCONF']['realurl']['sac-cas.ch'];
